Imports System.Drawing.Drawing2D

Public Class Shape
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Enum ShapeType
        Rectangle
        Ellipse
        Triangle
    End Enum

    Private _Shape As ShapeType = ShapeType.Rectangle
    Private _Path As GraphicsPath

    Public Property Shape() As ShapeType
        Get
            Return _Shape
        End Get
        Set(ByVal Value As ShapeType)
            _Shape = Value
            RefreshPath()
            Me.Invalidate()
        End Set
    End Property

    Private Sub RefreshPath()
        _Path = New GraphicsPath()
        Select Case _Shape
            Case ShapeType.Rectangle
                _Path.AddRectangle(Me.ClientRectangle)
            Case ShapeType.Ellipse
                _Path.AddEllipse(Me.ClientRectangle)
            Case ShapeType.Triangle
                Dim pt1 = New Point(Me.Width \ 2, 0)
                Dim pt2 = New Point(0, Me.Height)
                Dim pt3 = New Point(Me.Width, Me.Height)
                _Path.AddPolygon(New Point() {pt1, pt2, pt3})
        End Select
        Me.Region = New Region(_Path)
    End Sub

    Protected Overrides Sub OnResize(ByVal e As System.EventArgs)
        MyBase.OnResize(e)
        RefreshPath()
        Me.Invalidate()
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
        e.Graphics.FillPath(New SolidBrush(Me.BackColor), _Path)
        e.Graphics.DrawPath(New Pen(Me.ForeColor, 4), _Path)
    End Sub

End Class
