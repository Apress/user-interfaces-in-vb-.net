Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents HotTrackButton1 As HotTrackButton.HotTrackButton
    Friend WithEvents HotTrackButton2 As HotTrackButton.HotTrackButton
    Friend WithEvents HotTrackButton3 As HotTrackButton.HotTrackButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.HotTrackButton1 = New HotTrackButton.HotTrackButton()
        Me.HotTrackButton2 = New HotTrackButton.HotTrackButton()
        Me.HotTrackButton3 = New HotTrackButton.HotTrackButton()
        Me.SuspendLayout()
        '
        'HotTrackButton1
        '
        Me.HotTrackButton1.BackColor = System.Drawing.SystemColors.Control
        Me.HotTrackButton1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HotTrackButton1.ForeColor = System.Drawing.Color.Black
        Me.HotTrackButton1.Image = CType(resources.GetObject("HotTrackButton1.Image"), System.Drawing.Bitmap)
        Me.HotTrackButton1.Location = New System.Drawing.Point(24, 32)
        Me.HotTrackButton1.Name = "HotTrackButton1"
        Me.HotTrackButton1.Size = New System.Drawing.Size(168, 28)
        Me.HotTrackButton1.TabIndex = 0
        Me.HotTrackButton1.Text = "Ordinary HotTrackButton"
        '
        'HotTrackButton2
        '
        Me.HotTrackButton2.BackColor = System.Drawing.SystemColors.Control
        Me.HotTrackButton2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HotTrackButton2.ForeColor = System.Drawing.Color.Black
        Me.HotTrackButton2.Image = CType(resources.GetObject("HotTrackButton2.Image"), System.Drawing.Bitmap)
        Me.HotTrackButton2.Location = New System.Drawing.Point(24, 128)
        Me.HotTrackButton2.Name = "HotTrackButton2"
        Me.HotTrackButton2.Size = New System.Drawing.Size(168, 64)
        Me.HotTrackButton2.TabIndex = 1
        Me.HotTrackButton2.Text = "Large Icon HotTrackButton"
        '
        'HotTrackButton3
        '
        Me.HotTrackButton3.BackColor = System.Drawing.SystemColors.Control
        Me.HotTrackButton3.Enabled = False
        Me.HotTrackButton3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HotTrackButton3.ForeColor = System.Drawing.Color.Black
        Me.HotTrackButton3.Image = CType(resources.GetObject("HotTrackButton3.Image"), System.Drawing.Bitmap)
        Me.HotTrackButton3.Location = New System.Drawing.Point(24, 80)
        Me.HotTrackButton3.Name = "HotTrackButton3"
        Me.HotTrackButton3.Size = New System.Drawing.Size(168, 28)
        Me.HotTrackButton3.TabIndex = 2
        Me.HotTrackButton3.Text = "Disabled HotTrackButton"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(252, 226)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.HotTrackButton3, Me.HotTrackButton2, Me.HotTrackButton1})
        Me.Name = "Form1"
        Me.Text = "HotTrackButton Client"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
