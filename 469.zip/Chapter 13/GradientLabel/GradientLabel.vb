Imports System.ComponentModel
Imports System.Drawing.Drawing2D
Imports System.Drawing.Design

Public Class GradientLabel
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'GradientLabel
        '
        Me.Name = "GradientLabel"
        Me.Size = New System.Drawing.Size(312, 76)

    End Sub

#End Region

    ' Ensure it will be repainted when resized.
    Private Sub GradientLabel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ResizeRedraw = True
    End Sub

    Private _Text As String

    <Browsable(True), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)> _
    Public Overrides Property Text() As String
        Get
            Return _Text
        End Get
        Set(ByVal Value As String)
            _Text = Value
            Me.Invalidate()
        End Set
    End Property

    Private WithEvents _Gradient As New GradientFill()

    <DesignerSerializationVisibility(DesignerSerializationVisibility.Content)> _
    Public Property GradientFill() As GradientFill
        Get
            Return _Gradient
        End Get
        Set(ByVal Value As GradientFill)
            _Gradient = Value
            Me.Invalidate()
        End Set
    End Property

    Protected Overrides Sub OnPaintBackground(ByVal e As System.Windows.Forms.PaintEventArgs)
        Dim Brush As New LinearGradientBrush(e.ClipRectangle, _Gradient.ColorA, _Gradient.ColorB, _Gradient.GradientFillStyle)
        e.Graphics.FillRectangle(Brush, e.ClipRectangle)
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        e.Graphics.DrawString(_Text, Me.Font, New SolidBrush(Me.ForeColor), 0, 0)
    End Sub

    Private Sub _Gradient_GradientChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _Gradient.GradientChanged
        Me.Invalidate()
    End Sub
End Class

<TypeConverter(GetType(ExpandableObjectConverter)), _
Editor(GetType(GradientFillEditor), GetType(UITypeEditor))> _
Public Class GradientFill

    Private _ColorA As Color = Color.LightBlue
    Private _ColorB As Color = Color.Purple
    Private _GradientStyle As LinearGradientMode = LinearGradientMode.ForwardDiagonal

    Event GradientChanged As EventHandler

    Public Property ColorA() As Color
        Get
            Return _ColorA
        End Get
        Set(ByVal Value As Color)
            _ColorA = Value
            RaiseEvent GradientChanged(Me, New EventArgs())
        End Set
    End Property

    Public Property ColorB() As Color
        Get
            Return _ColorB
        End Get
        Set(ByVal Value As Color)
            _ColorB = Value
            RaiseEvent GradientChanged(Me, New EventArgs())
        End Set
    End Property

    <System.ComponentModel.RefreshProperties(RefreshProperties.Repaint)> _
    Public Property GradientFillStyle() As LinearGradientMode
        Get
            Return _GradientStyle
        End Get
        Set(ByVal Value As LinearGradientMode)
            _GradientStyle = Value
            RaiseEvent GradientChanged(Me, New EventArgs())
        End Set
    End Property
End Class

Public Class GradientFillEditor
    Inherits UITypeEditor

    Public Overloads Overrides Function GetPaintValueSupported(ByVal context As System.ComponentModel.ITypeDescriptorContext) As Boolean
        Return True
    End Function

    Public Overloads Overrides Sub PaintValue(ByVal e As System.Drawing.Design.PaintValueEventArgs)
        Dim Fill As GradientFill = CType(e.Value, GradientFill)
        Dim Brush As New LinearGradientBrush(e.Bounds, Fill.ColorA, Fill.ColorB, Fill.GradientFillStyle)

        ' Paint the thumbnail.
        e.Graphics.FillRectangle(Brush, e.Bounds)
    End Sub

End Class

