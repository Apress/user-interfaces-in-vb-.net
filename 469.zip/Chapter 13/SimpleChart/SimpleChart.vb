Public Class SimpleChart
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Private _Bars As New BarItemCollection()

    Public Property Bars() As BarItemCollection
        Get
            Return _Bars
        End Get
        Set(ByVal Value As BarItemCollection)
            _Bars = Value
            RebuildChart()
        End Set
    End Property

    Private Sub SimpleChart_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ResizeRedraw = True
    End Sub

    Private _BarWidth, _MaxValue As Integer

    Public Sub RebuildChart()
        If Bars.Count = 0 Then Exit Sub

        ' Find out how much space a single bar can occupy.
        _BarWidth = Me.Width \ _Bars.Count

        ' Set the maximum value on the chart.
        _MaxValue = 0
        Dim Bar As BarItem
        For Each Bar In _Bars
            If Bar.Value > _MaxValue Then _MaxValue = Bar.Value
        Next

        Me.Invalidate()
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)

        If _Bars.Count = 0 Then Exit Sub

        ' Draw the bacground for each item.
        Dim X As Integer = 0
        Dim BaseLine As Integer = Me.Height
        Dim Bar As BarItem

        ' Draw each item.
        For Each Bar In _Bars
            Dim Height As Integer = CType(Bar.Value / _MaxValue * Me.Height, Integer)
            Dim Top As Integer = Me.Height - Height

            ' Draw bar (two rectangles are used for a shadowed effect),
            ' along with an outline.
            e.Graphics.FillRectangle(Brushes.LightBlue, X + 4, Top, _BarWidth - 7, Height)
            e.Graphics.DrawRectangle(New Pen(Color.White, 4), X + 4, Top, _BarWidth - 4, Height)
            e.Graphics.FillRectangle(Brushes.SteelBlue, X + 8, Top + 4, _BarWidth - 9, Height - 5)

            ' Draw title.
            Dim TextFont As New Font("Tahoma", 8)
            e.Graphics.DrawString(Bar.ShortForm, TextFont, Brushes.White, X + 15, Top + 5)


            X += _BarWidth
        Next

        ' Draw the grid.
        e.Graphics.DrawLine(Pens.Black, 0, Me.Height - 1, Me.Width, Me.Height - 1)
        e.Graphics.DrawLine(Pens.Black, 0, 0, 0, Me.Height)

    End Sub

    Private Sub SimpleChart_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        RebuildChart()
        Me.Invalidate()
    End Sub
End Class

Public Class BarItemCollection
    Inherits CollectionBase

    Public Sub Add(ByVal item As BarItem)
        Me.List.Add(item)
    End Sub

    Public Sub Remove(ByVal index As Integer)
        ' Check to see if there is an item at the supplied index.
        If index > Count - 1 Or index < 0 Then
            Throw New System.IndexOutOfRangeException()
        Else
            List.RemoveAt(index)
        End If
    End Sub

    Public Property Item(ByVal index As Integer) As BarItem
        Get
            ' The appropriate item is retrieved from the List object and 
            ' explicitly cast to the BarItem type.
            Return CType(List.Item(index), BarItem)
        End Get
        Set(ByVal Value As BarItem)
            List.Item(index) = Value
        End Set
    End Property

End Class

Public Class BarItem
    Public ShortForm As String
    Public Value As Decimal

    Public Sub New(ByVal ShortForm As String, ByVal value As Decimal)
        Me.ShortForm = ShortForm
        Me.Value = value
    End Sub
End Class