Public Class HotTrackButton
    Inherits Control

    Public Enum State
        Normal
        MouseOver
        Pushed
    End Enum

    Private _State As State = State.Normal
    Private _Image As Image
    Private _Bounds As Rectangle

    Public Property Image() As Image
        Get
            Return _Image
        End Get
        Set(ByVal Value As Image)
            _Image = Value
            _Bounds = New Rectangle(0, 0, _Image.Width + 5, _Image.Height + 5)
            Me.Invalidate()
        End Set
    End Property

    ' You must override this property to invalidate the control and
    ' provide automatic refresh when the property is changed.
    Public Overrides Property Text() As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal Value As String)
            MyBase.Text = Value
            Me.Invalidate()
        End Set
    End Property

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)

        If _Image Is Nothing Then
            ' Draw the text without the image.
            e.Graphics.DrawString(Me.Text, Me.Font, New SolidBrush(Me.ForeColor), 10, 0)
        Else

            If Me.Enabled = False Then
                ' Paint the picture in a disabled state.
                ControlPaint.DrawImageDisabled(e.Graphics, _Image, 2, 2, Me.BackColor)
            Else
                ' Paint the image according the button state.
                Select Case _State
                    Case State.Normal
                        e.Graphics.DrawImage(_Image, 2, 2)
                    Case State.MouseOver
                        ControlPaint.DrawBorder3D(e.Graphics, _Bounds, Border3DStyle.Raised, Border3DSide.All)
                        e.Graphics.DrawImage(_Image, 2, 2)
                    Case State.Pushed
                        ControlPaint.DrawBorder3D(e.Graphics, _Bounds, Border3DStyle.Sunken, Border3DSide.All)
                        e.Graphics.DrawImage(_Image, 3, 3)
                End Select
            End If

            ' Paint the caption text next to the image.
            e.Graphics.DrawString(Me.Text, Me.Font, New SolidBrush(Me.ForeColor), _Bounds.Width + 3, (_Bounds.Height - Me.Font.Height) \ 2)

        End If

    End Sub

    Protected Overrides Sub OnMouseMove(ByVal e As System.Windows.Forms.MouseEventArgs)
        MyBase.OnMouseMove(e)

        ' Check if the mouse pointer is over the button.
        ' If the mouse moves off the button surface, it will be deactivated,
        ' even if the button is being held in a pressed position.
        ' The code repaints the button only if needed.
        If _Bounds.Contains(e.X, e.Y) Then
            If _State = State.Normal Then
                _State = State.MouseOver
                Me.Invalidate(_Bounds)
            End If
        Else
            If _State <> State.Normal Then
                _State = State.Normal
                Me.Invalidate(_Bounds)
            End If
        End If
    End Sub

    Protected Overrides Sub OnMouseLeave(ByVal e As System.EventArgs)
        ' Reset the button appearance. This will also deactivate the button
        ' if it has been pressed but not released.
        ' The code repaints the button only if needed.
        If _State <> State.Normal Then
            _State = State.Normal
            Me.Invalidate(_Bounds)
        End If
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As System.Windows.Forms.MouseEventArgs)
        ' Change the button to a pushed state, provided the mouse pointer is
        ' over the image and the Left mouse button has been clicked 
        If _Bounds.Contains(e.X, e.Y) And (e.Button And MouseButtons.Left = MouseButtons.Left) Then
            _State = State.Pushed
            Me.Invalidate(_Bounds)
        End If
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal e As System.Windows.Forms.MouseEventArgs)
        ' Change the button to a normal state and repaint if needed.
        If Not e.Button And MouseButtons.Left = MouseButtons.Left Then
            _State = State.Normal

            If _Bounds.Contains(e.X, e.Y) Then
                _State = State.MouseOver
            Else
                _State = State.Normal
            End If

            Me.Invalidate(_Bounds)
        End If
    End Sub

    Protected Overrides Sub OnClick(ByVal e As System.EventArgs)
        ' Only propagate the click to the client if it was detected over the image.
        If _State = State.Pushed Then
            MyBase.OnClick(e)
        End If
    End Sub
End Class
