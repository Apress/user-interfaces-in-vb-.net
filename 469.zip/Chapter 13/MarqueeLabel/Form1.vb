Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbAmount As System.Windows.Forms.TrackBar
    Friend WithEvents tbInterval As System.Windows.Forms.TrackBar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MarqueeLabel1 As MarqueeLabelTest.MarqueeLabel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MarqueeLabel1 = New MarqueeLabelTest.MarqueeLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbInterval = New System.Windows.Forms.TrackBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbAmount = New System.Windows.Forms.TrackBar()
        Me.GroupBox1.SuspendLayout()
        CType(Me.tbInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MarqueeLabel1
        '
        Me.MarqueeLabel1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.MarqueeLabel1.Font = New System.Drawing.Font("Verdana", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MarqueeLabel1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.MarqueeLabel1.Location = New System.Drawing.Point(0, 12)
        Me.MarqueeLabel1.Name = "MarqueeLabel1"
        Me.MarqueeLabel1.ScrollTimeInterval = 100
        Me.MarqueeLabel1.Size = New System.Drawing.Size(352, 112)
        Me.MarqueeLabel1.TabIndex = 0
        Me.MarqueeLabel1.Text = "This scrolls!"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.tbInterval, Me.Label1, Me.tbAmount})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Location = New System.Drawing.Point(8, 136)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 132)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(12, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 23)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Scroll Interval:"
        '
        'tbInterval
        '
        Me.tbInterval.Location = New System.Drawing.Point(96, 72)
        Me.tbInterval.Maximum = 500
        Me.tbInterval.Minimum = 10
        Me.tbInterval.Name = "tbInterval"
        Me.tbInterval.Size = New System.Drawing.Size(228, 45)
        Me.tbInterval.TabIndex = 5
        Me.tbInterval.TickFrequency = 10
        Me.tbInterval.Value = 100
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(12, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 23)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Scroll Amount:"
        '
        'tbAmount
        '
        Me.tbAmount.Location = New System.Drawing.Point(96, 16)
        Me.tbAmount.Maximum = 20
        Me.tbAmount.Name = "tbAmount"
        Me.tbAmount.Size = New System.Drawing.Size(228, 45)
        Me.tbAmount.TabIndex = 3
        Me.tbAmount.Value = 1
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(352, 278)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.MarqueeLabel1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Marquee Label"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.tbInterval, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbAmount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub tbAmount_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbAmount.Scroll
        MarqueeLabel1.ScrollPixelAmount = tbAmount.Value
    End Sub

    Private Sub tbInterval_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbInterval.Scroll
        MarqueeLabel1.ScrollTimeInterval = tbInterval.Value
    End Sub
End Class
