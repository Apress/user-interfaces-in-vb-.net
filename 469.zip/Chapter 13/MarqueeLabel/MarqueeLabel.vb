Imports System.ComponentModel

Public Class MarqueeLabel
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tmrScroll As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrScroll = New System.Windows.Forms.Timer(Me.components)
        '
        'tmrScroll
        '
        '
        'MarqeeLabel
        '
        Me.Name = "MarqeeLabel"
        Me.Size = New System.Drawing.Size(312, 76)

    End Sub

#End Region

    Private _Text As String
    Private _ScrollAmount As Integer = 10
    Private _Position As Integer = 0

    <Browsable(True), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)> _
    Public Overrides Property Text() As String
        Get
            Return _Text
        End Get
        Set(ByVal Value As String)
            _Text = Value
            Me.Invalidate()
        End Set
    End Property

    Public Property ScrollTimeInterval() As Integer
        Get
            Return tmrScroll.Interval
        End Get
        Set(ByVal Value As Integer)
            tmrScroll.Interval = Value
        End Set
    End Property

    <DefaultValue(10)> _
    Public Property ScrollPixelAmount() As Integer
        Get
            Return _ScrollAmount
        End Get
        Set(ByVal Value As Integer)
            _ScrollAmount = Value
        End Set
    End Property

    Protected Overrides Sub OnPaintBackground(ByVal pevent As System.Windows.Forms.PaintEventArgs)
        ' Do nothing.
        ' To prevent flicker, we will draw both the background and the text
        ' to a buffered image, and draw it to the control all at once.
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        ' The following line avoids a design-time error that would
        ' otherwise occur when the control is first loaded (but does not yet
        ' have a defined size.
        If e.ClipRectangle.Width = 0 Then Exit Sub

        MyBase.OnPaint(e)
        If _Position > Me.Width Then
            _Position = -e.Graphics.MeasureString(_Text, Me.Font).Width
        End If

        ' Create the drawing area in memory.
        ' Double buffering is used to prevent flicker.
        Dim blt As New Bitmap(e.ClipRectangle.Width, e.ClipRectangle.Height)
        Dim g As Graphics = Graphics.FromImage(blt)

        g.FillRectangle(New SolidBrush(Me.BackColor), e.ClipRectangle)
        g.DrawString(_Text, Me.Font, New SolidBrush(Me.ForeColor), _Position, 0)

        ' Render the finished image on the form.
        e.Graphics.DrawImageUnscaled(blt, 0, 0)

        g.Dispose()
    End Sub


    Private Sub MarqeeLabel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ResizeRedraw = True
        If Me.DesignMode = False Then
            tmrScroll.Enabled = True
        End If
    End Sub

    Private Sub tmrScroll_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrScroll.Tick
        _Position += _ScrollAmount
        ' Force a refresh.
        Me.Invalidate()
    End Sub


End Class
