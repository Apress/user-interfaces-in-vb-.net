Public Class FormatAndParseImages
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cboModelName As System.Windows.Forms.ComboBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents picProduct As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cboModelName = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.picProduct = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboModelName
        '
        Me.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboModelName.Location = New System.Drawing.Point(80, 10)
        Me.cboModelName.Name = "cboModelName"
        Me.cboModelName.Size = New System.Drawing.Size(248, 21)
        Me.cboModelName.TabIndex = 1
        '
        'lblStatus
        '
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblStatus.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblStatus.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblStatus.Location = New System.Drawing.Point(0, 190)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(376, 24)
        Me.lblStatus.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Product:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.picProduct})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Location = New System.Drawing.Point(8, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(352, 128)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Display Value for ProductImage"
        '
        'picProduct
        '
        Me.picProduct.Location = New System.Drawing.Point(16, 24)
        Me.picProduct.Name = "picProduct"
        Me.picProduct.Size = New System.Drawing.Size(128, 88)
        Me.picProduct.TabIndex = 18
        Me.picProduct.TabStop = False
        '
        'FormatAndParseImages
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(376, 214)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.Label1, Me.lblStatus, Me.cboModelName})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "FormatAndParseImages"
        Me.Text = "Format And Parse"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FormatAndParse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dsStore As New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")

        cboModelName.DataSource = dsStore.Tables("Products")
        cboModelName.DisplayMember = "ModelName"

        Dim PictureBinding As New Binding("Image", dsStore.Tables("Products"), "ProductImage")
        AddHandler PictureBinding.Format, AddressOf FileToImage
        AddHandler PictureBinding.Parse, AddressOf ImageToFile

        picProduct.DataBindings.Add(PictureBinding)

        AddHandler dsStore.Tables("Products").ColumnChanged, AddressOf TableChanged

    End Sub

    Private Sub TableChanged(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
        lblStatus.Text = " Detected change. Column " & e.Column.ColumnName
        lblStatus.Text &= " updated to " & e.ProposedValue & "."
    End Sub


    Private Sub FileToImage(ByVal sender As Object, ByVal e As ConvertEventArgs)
        Debug.WriteLine(e.Value.ToString)
        If e.DesiredType Is GetType(Image) Then

            picProduct.Tag = e.Value
            ' Look up the corresponding file, and create an Image object.
            Dim im As Image
            im = Image.FromFile(Application.StartupPath & "\" & e.Value)

            e.Value = im
        End If

    End Sub

    Private Sub ImageToFile(ByVal sender As Object, ByVal e As ConvertEventArgs)

        If e.DesiredType Is GetType(String) Then

            ' Look up the corresponding file, and create an Image object.
            e.Value = picProduct.Tag

        End If

    End Sub


End Class


