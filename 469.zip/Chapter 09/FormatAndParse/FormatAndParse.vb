Imports System.Drawing

Public Class FormatAndParse
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cboModelName As System.Windows.Forms.ComboBox
    Friend WithEvents txtUnitCost As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cboModelName = New System.Windows.Forms.ComboBox()
        Me.txtUnitCost = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboModelName
        '
        Me.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboModelName.Location = New System.Drawing.Point(80, 10)
        Me.cboModelName.Name = "cboModelName"
        Me.cboModelName.Size = New System.Drawing.Size(248, 21)
        Me.cboModelName.TabIndex = 1
        '
        'txtUnitCost
        '
        Me.txtUnitCost.Location = New System.Drawing.Point(150, 35)
        Me.txtUnitCost.Name = "txtUnitCost"
        Me.txtUnitCost.Size = New System.Drawing.Size(128, 21)
        Me.txtUnitCost.TabIndex = 14
        Me.txtUnitCost.Text = ""
        '
        'lblStatus
        '
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblStatus.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblStatus.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblStatus.Location = New System.Drawing.Point(0, 198)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(372, 24)
        Me.lblStatus.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Product:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 16)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Display Value for Price:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtUnitCost, Me.Label2})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Location = New System.Drawing.Point(8, 40)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(352, 136)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        '
        'FormatAndParse
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(372, 222)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.Label1, Me.lblStatus, Me.cboModelName})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "FormatAndParse"
        Me.Text = "Format And Parse"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FormatAndParse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dsStore As New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")

        cboModelName.DataSource = dsStore.Tables("Products")
        cboModelName.DisplayMember = "ModelName"

        Dim CostBinding As New Binding("Text", dsStore.Tables("Products"), "UnitCost")
        AddHandler CostBinding.Format, AddressOf DecimalToCurrencyString
        AddHandler CostBinding.Parse, AddressOf CurrencyStringToDecimal
        txtUnitCost.DataBindings.Add(CostBinding)

        AddHandler dsStore.Tables("Products").ColumnChanged, AddressOf TableChanged

    End Sub

    Private Sub DecimalToCurrencyString(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If e.DesiredType Is GetType(String) Then
            ' Use the ToString method to format the value as currency ("c").
            e.Value = CType(e.Value, Decimal).ToString("c")
        End If
    End Sub

    Private Sub CurrencyStringToDecimal(ByVal sender As Object, ByVal e As ConvertEventArgs)

        If e.DesiredType Is GetType(Decimal) Then
            ' Convert the string back to decimal using the shared Parse method.
            e.Value = Decimal.Parse(e.Value.ToString, _
           Globalization.NumberStyles.Currency, Nothing)
        End If
    End Sub

    Private Sub TableChanged(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
        lblStatus.Text = " Detected change. Column " & e.Column.ColumnName
        lblStatus.Text &= " updated to " & e.ProposedValue & "."
    End Sub

End Class


