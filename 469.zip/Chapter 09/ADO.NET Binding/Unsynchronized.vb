Public Class Unsynchronized
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grpCategory As System.Windows.Forms.GroupBox
    Friend WithEvents lstCategory As System.Windows.Forms.ListBox
    Friend WithEvents lstProduct As System.Windows.Forms.ListBox
    Friend WithEvents grp As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstCategory = New System.Windows.Forms.ListBox()
        Me.lstProduct = New System.Windows.Forms.ListBox()
        Me.grpCategory = New System.Windows.Forms.GroupBox()
        Me.grp = New System.Windows.Forms.GroupBox()
        Me.grpCategory.SuspendLayout()
        Me.grp.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstCategory
        '
        Me.lstCategory.Location = New System.Drawing.Point(16, 24)
        Me.lstCategory.Name = "lstCategory"
        Me.lstCategory.Size = New System.Drawing.Size(248, 95)
        Me.lstCategory.TabIndex = 0
        '
        'lstProduct
        '
        Me.lstProduct.Location = New System.Drawing.Point(16, 24)
        Me.lstProduct.Name = "lstProduct"
        Me.lstProduct.Size = New System.Drawing.Size(248, 95)
        Me.lstProduct.TabIndex = 1
        '
        'grpCategory
        '
        Me.grpCategory.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstCategory})
        Me.grpCategory.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpCategory.Location = New System.Drawing.Point(8, 8)
        Me.grpCategory.Name = "grpCategory"
        Me.grpCategory.Size = New System.Drawing.Size(280, 136)
        Me.grpCategory.TabIndex = 2
        Me.grpCategory.TabStop = False
        '
        'grp
        '
        Me.grp.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstProduct})
        Me.grp.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grp.Location = New System.Drawing.Point(8, 152)
        Me.grp.Name = "grp"
        Me.grp.Size = New System.Drawing.Size(280, 136)
        Me.grp.TabIndex = 3
        Me.grp.TabStop = False
        '
        'Unsynchronized
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(308, 306)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grp, Me.grpCategory})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Unsynchronized"
        Me.Text = "Two Binding Contexts"
        Me.grpCategory.ResumeLayout(False)
        Me.grp.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ParentChild_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Create a separate binding context for .
        grpCategory.BindingContext = New BindingContext()

        Dim dsStore As New DataSet()
        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")
  
        lstCategory.DataSource = dsStore.Tables("Categories")
        lstCategory.DisplayMember = "CategoryName"

        lstProduct.DataSource = dsStore.Tables("Categories")
        lstProduct.DisplayMember = "CategoryName"

    End Sub
End Class
