Public Class EditableBinding
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cboModelName As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtModelName As System.Windows.Forms.TextBox
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitCost As System.Windows.Forms.TextBox
    Friend WithEvents txtModelNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cboModelName = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtModelName = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtUnitCost = New System.Windows.Forms.TextBox()
        Me.txtModelNumber = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboModelName
        '
        Me.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboModelName.Location = New System.Drawing.Point(104, 12)
        Me.cboModelName.Name = "cboModelName"
        Me.cboModelName.Size = New System.Drawing.Size(308, 21)
        Me.cboModelName.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label3, Me.Label2, Me.Label1, Me.txtModelName, Me.txtDescription, Me.txtUnitCost, Me.txtModelNumber})
        Me.GroupBox1.Location = New System.Drawing.Point(12, 52)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(400, 252)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        '
        'txtModelName
        '
        Me.txtModelName.Location = New System.Drawing.Point(68, 24)
        Me.txtModelName.Name = "txtModelName"
        Me.txtModelName.Size = New System.Drawing.Size(316, 21)
        Me.txtModelName.TabIndex = 15
        Me.txtModelName.Text = ""
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(12, 92)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(372, 116)
        Me.txtDescription.TabIndex = 14
        Me.txtDescription.Text = ""
        '
        'txtUnitCost
        '
        Me.txtUnitCost.Location = New System.Drawing.Point(256, 52)
        Me.txtUnitCost.Name = "txtUnitCost"
        Me.txtUnitCost.Size = New System.Drawing.Size(128, 21)
        Me.txtUnitCost.TabIndex = 13
        Me.txtUnitCost.Text = ""
        '
        'txtModelNumber
        '
        Me.txtModelNumber.Location = New System.Drawing.Point(68, 52)
        Me.txtModelNumber.Name = "txtModelNumber"
        Me.txtModelNumber.Size = New System.Drawing.Size(136, 21)
        Me.txtModelNumber.TabIndex = 12
        Me.txtModelNumber.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 16)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Name:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 16)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Model:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(220, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 16)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Cost:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(12, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 16)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Select a Record:"
        '
        'EditableBinding
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(432, 318)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.GroupBox1, Me.cboModelName})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "EditableBinding"
        Me.Text = "Editable Binding"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public StoreBinding As BindingManagerBase

    Private Sub EditableBinding_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dsStore As New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")

        cboModelName.DataSource = dsStore.Tables("Products")
        cboModelName.DisplayMember = "ModelName"

        txtModelName.DataBindings.Add("Text", dsStore.Tables("Products"), "ModelName")
        txtModelNumber.DataBindings.Add("Text", dsStore.Tables("Products"), "ModelNumber")
        txtUnitCost.DataBindings.Add("Text", dsStore.Tables("Products"), "UnitCost")
        txtDescription.DataBindings.Add("Text", dsStore.Tables("Products"), "Description")

        StoreBinding = Me.BindingContext(dsStore.Tables("Products"))
    End Sub
End Class
