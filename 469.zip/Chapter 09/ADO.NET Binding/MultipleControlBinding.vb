Public Class MultipleControlBinding
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cboModelName As System.Windows.Forms.ComboBox
    Friend WithEvents cmdPrev As System.Windows.Forms.Button
    Friend WithEvents cmdNext As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblUnitCost As System.Windows.Forms.Label
    Friend WithEvents lblModelNumber As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cboModelName = New System.Windows.Forms.ComboBox()
        Me.cmdPrev = New System.Windows.Forms.Button()
        Me.cmdNext = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblUnitCost = New System.Windows.Forms.Label()
        Me.lblModelNumber = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboModelName
        '
        Me.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboModelName.Location = New System.Drawing.Point(12, 12)
        Me.cboModelName.Name = "cboModelName"
        Me.cboModelName.Size = New System.Drawing.Size(316, 21)
        Me.cboModelName.TabIndex = 0
        '
        'cmdPrev
        '
        Me.cmdPrev.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
        Me.cmdPrev.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdPrev.Location = New System.Drawing.Point(16, 228)
        Me.cmdPrev.Name = "cmdPrev"
        Me.cmdPrev.Size = New System.Drawing.Size(92, 28)
        Me.cmdPrev.TabIndex = 4
        Me.cmdPrev.Text = "<< Prev"
        '
        'cmdNext
        '
        Me.cmdNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdNext.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdNext.Location = New System.Drawing.Point(236, 228)
        Me.cmdNext.Name = "cmdNext"
        Me.cmdNext.Size = New System.Drawing.Size(92, 28)
        Me.cmdNext.TabIndex = 5
        Me.cmdNext.Text = "Next >>"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblDescription, Me.lblUnitCost, Me.lblModelNumber})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Location = New System.Drawing.Point(16, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(312, 168)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'lblDescription
        '
        Me.lblDescription.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblDescription.Location = New System.Drawing.Point(8, 57)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(296, 99)
        Me.lblDescription.TabIndex = 6
        '
        'lblUnitCost
        '
        Me.lblUnitCost.Location = New System.Drawing.Point(168, 16)
        Me.lblUnitCost.Name = "lblUnitCost"
        Me.lblUnitCost.Size = New System.Drawing.Size(136, 32)
        Me.lblUnitCost.TabIndex = 5
        '
        'lblModelNumber
        '
        Me.lblModelNumber.Location = New System.Drawing.Point(8, 16)
        Me.lblModelNumber.Name = "lblModelNumber"
        Me.lblModelNumber.Size = New System.Drawing.Size(140, 32)
        Me.lblModelNumber.TabIndex = 4
        '
        'MultipleControlBinding
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(344, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.cmdNext, Me.cmdPrev, Me.cboModelName})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "MultipleControlBinding"
        Me.Text = "Manual Navigation Control"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public StoreBinding As BindingManagerBase


    Private Sub MultipleControlBinding_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dsStore As New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")
        dsStore.Tables("Products").DefaultView.AllowDelete = False
        dsStore.Tables("Products").DefaultView.RowFilter = "UnitCost < 5"

        cboModelName.DataSource = dsStore.Tables("Products")
        cboModelName.DisplayMember = "ModelName"

        lblModelNumber.DataBindings.Add("Text", dsStore.Tables("Products"), "ModelNumber")
        lblUnitCost.DataBindings.Add("Text", dsStore.Tables("Products"), "UnitCost")
        lblDescription.DataBindings.Add("Text", dsStore.Tables("Products"), "Description")

        StoreBinding = Me.BindingContext(dsStore.Tables("Products"))
    End Sub

    Private Sub cmdPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrev.Click
        StoreBinding.Position -= 1
    End Sub

    Private Sub cmdNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNext.Click
        StoreBinding.Position += 1
    End Sub
End Class

