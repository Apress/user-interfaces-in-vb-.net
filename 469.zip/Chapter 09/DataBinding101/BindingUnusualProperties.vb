Imports System.ComponentModel
Public Class BindingUnusualProperties
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstColors As System.Windows.Forms.ListBox
    Friend WithEvents lblSampleText As System.Windows.Forms.Label
    Friend WithEvents lstFonts As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstColors = New System.Windows.Forms.ListBox()
        Me.lblSampleText = New System.Windows.Forms.Label()
        Me.lstFonts = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstColors
        '
        Me.lstColors.Location = New System.Drawing.Point(12, 28)
        Me.lstColors.Name = "lstColors"
        Me.lstColors.Size = New System.Drawing.Size(176, 134)
        Me.lstColors.TabIndex = 0
        '
        'lblSampleText
        '
        Me.lblSampleText.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblSampleText.Location = New System.Drawing.Point(16, 184)
        Me.lblSampleText.Name = "lblSampleText"
        Me.lblSampleText.Size = New System.Drawing.Size(372, 96)
        Me.lblSampleText.TabIndex = 1
        Me.lblSampleText.Text = "Click an item in one of the lists above to change the font or color of this text." & _
        " Once the initial conditions are set up (i.e., the binding), this operation happ" & _
        "ens automatically."
        '
        'lstFonts
        '
        Me.lstFonts.Location = New System.Drawing.Point(208, 28)
        Me.lstFonts.Name = "lstFonts"
        Me.lstFonts.Size = New System.Drawing.Size(180, 134)
        Me.lstFonts.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(12, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 12)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Choose a Color:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(208, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Choose a Font:"
        '
        'BindingUnusualProperties
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(404, 294)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.Label1, Me.lstFonts, Me.lblSampleText, Me.lstColors})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "BindingUnusualProperties"
        Me.Text = "Binding Unusual Properties"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub BindingUnusualProperties_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' These are our final data sources: two ArrayList objects.
        Dim FontObjList As New ArrayList()
        Dim ColorObjList As New ArrayList()

        ' The InstalledFonts collection allows us to enumerate installed fonts.
        ' Each FontFamily needs to be converted to a genuine Font object
        ' before it is suitable for data binding to the Control.Font property.
        Dim Family As FontFamily
        Dim InstalledFonts As New System.Drawing.Text.InstalledFontCollection()
        For Each Family In InstalledFonts.Families
            Try
                FontObjList.Add(New Font(Family, 12))
            Catch
                ' We end up here if the font could not be created
                ' with the default style.
            End Try
        Next

        ' In order to retrieve the list of colors, we need to first retrieve
        ' the strings for the KnownColor enumeration, and then convert each one
        ' into a suitable color object.
        Dim ColorNames(), ColorName As String
        ColorNames = System.Enum.GetNames(GetType(System.Drawing.KnownColor))
        Dim cnvrt As TypeConverter = TypeDescriptor.GetConverter(GetType(KnownColor))

        For Each ColorName In ColorNames
            ColorObjList.Add(System.Drawing.Color.FromKnownColor(cnvrt.ConvertFromString(ColorName)))
        Next

        ' We can now bind both our list controls.
        lstColors.DataSource = ColorObjList
        lstColors.DisplayMember = "Name"
        lstFonts.DataSource = FontObjList
        lstFonts.DisplayMember = "Name"

        ' The label is boudn to both data sources.
        lblSampleText.DataBindings.Add("ForeColor", ColorObjList, "")
        lblSampleText.DataBindings.Add("Font", FontObjList, "")

    End Sub
End Class
