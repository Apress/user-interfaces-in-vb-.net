Public Class ObjectListBinding2
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstCity As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstCity = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lstCity
        '
        Me.lstCity.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lstCity.IntegralHeight = False
        Me.lstCity.Location = New System.Drawing.Point(8, 8)
        Me.lstCity.Name = "lstCity"
        Me.lstCity.Size = New System.Drawing.Size(220, 192)
        Me.lstCity.TabIndex = 2
        '
        'ObjectListBinding2
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(236, 210)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstCity})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ObjectListBinding2"
        Me.Text = "Object List Binding"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private Sub ObjectListBinding_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim CityChoices() As City2 = {New City2("Seattle", "U.S.A."), New City2("New York", "U.S.A."), New City2("Tokyo", "Japan"), New City2("Montreal", "Canada")}
        lstCity.DataSource = CityChoices
    End Sub

    Private Sub lstCity_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstCity.DoubleClick
        MessageBox.Show(CType(lstCity.SelectedItem, City).Country)
    End Sub
End Class

Public Class City2

    Public Name As String
    Public Country As String

    
    Public Sub New(ByVal name As String, ByVal country As String)
        Me.Name = name
        Me.Country = country
    End Sub

    Public Overrides Function ToString() As String
        Return Name & ", " & Country
    End Function


End Class