Public Class ObjectListBinding
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstCity As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstCity = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lstCity
        '
        Me.lstCity.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lstCity.IntegralHeight = False
        Me.lstCity.Location = New System.Drawing.Point(8, 8)
        Me.lstCity.Name = "lstCity"
        Me.lstCity.Size = New System.Drawing.Size(208, 192)
        Me.lstCity.TabIndex = 1
        '
        'ObjectListBinding
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(228, 210)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstCity})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ObjectListBinding"
        Me.Text = "ObjectListBinding"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ObjectListBinding_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim CityChoices() As City = {New City("Seattle", "U.S.A."), New City("New York", "U.S.A."), New City("Tokyo", "Japan"), New City("Montreal", "Canada")}
        lstCity.DataSource = CityChoices
        'lstCity.DisplayMember = "Name"
    End Sub

    Private Sub lstCity_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstCity.DoubleClick
        MessageBox.Show(CType(lstCity.SelectedItem, City).Country)
    End Sub

 
End Class

Public Class City

    Private _Name As String
    Private _Country As String

    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal Value As String)
            _Name = Value
        End Set
    End Property

    Public Property Country() As String
        Get
            Return _Country
        End Get
        Set(ByVal Value As String)
            _Country = Value
        End Set
    End Property

    Public Sub New(ByVal name As String, ByVal country As String)
        Me.Name = name
        Me.Country = country
    End Sub

End Class