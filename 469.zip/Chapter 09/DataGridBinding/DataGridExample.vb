Public Class DataGridExample
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grid As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grid = New System.Windows.Forms.DataGrid()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grid
        '
        Me.grid.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grid.DataMember = ""
        Me.grid.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grid.Location = New System.Drawing.Point(8, 8)
        Me.grid.Name = "grid"
        Me.grid.Size = New System.Drawing.Size(272, 232)
        Me.grid.TabIndex = 0
        '
        'DataGridExample
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(288, 254)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grid})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "DataGridExample"
        Me.Text = "DataGrid"
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DataGridExample_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dsStore As  New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")

        ' Create a relation between categories and products.
        Dim dr As New DataRelation("Products in this category", _
          dsStore.Tables("Categories").Columns("CategoryID"), _
          dsStore.Tables("Products").Columns("CategoryID"))

        ' Add the relation to the DataSet.
        dsStore.Relations.Add(dr)

        ' Bind the data grid.
        grid.DataSource = dsStore.Tables("Categories")


    End Sub


End Class
