Imports System.Data.SqlClient

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents treeDB As System.Windows.Forms.TreeView
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents imgTree As System.Windows.Forms.ImageList
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.treeDB = New System.Windows.Forms.TreeView()
        Me.imgTree = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdClose, Me.GroupBox1})
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(5, 269)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(446, 36)
        Me.Panel1.TabIndex = 5
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdClose.Location = New System.Drawing.Point(372, 12)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(72, 24)
        Me.cmdClose.TabIndex = 4
        Me.cmdClose.Text = "Close"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(444, 8)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel3, Me.Splitter1, Me.treeDB})
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(5, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(446, 264)
        Me.Panel2.TabIndex = 6
        '
        'Panel3
        '
        Me.Panel3.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblInfo, Me.Label1})
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(239, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(207, 264)
        Me.Panel3.TabIndex = 7
        '
        'lblInfo
        '
        Me.lblInfo.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lblInfo.BackColor = System.Drawing.SystemColors.Window
        Me.lblInfo.Location = New System.Drawing.Point(16, 12)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(176, 240)
        Me.lblInfo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.Label1.BackColor = System.Drawing.SystemColors.Window
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(200, 264)
        Me.Label1.TabIndex = 2
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(236, 0)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(3, 264)
        Me.Splitter1.TabIndex = 6
        Me.Splitter1.TabStop = False
        '
        'treeDB
        '
        Me.treeDB.Dock = System.Windows.Forms.DockStyle.Left
        Me.treeDB.ImageList = Me.imgTree
        Me.treeDB.Name = "treeDB"
        Me.treeDB.Size = New System.Drawing.Size(236, 264)
        Me.treeDB.TabIndex = 4
        '
        'imgTree
        '
        Me.imgTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.imgTree.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgTree.ImageStream = CType(resources.GetObject("imgTree.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgTree.TransparentColor = System.Drawing.Color.Transparent
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(456, 310)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel2, Me.Panel1})
        Me.DockPadding.All = 5
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Embedding Control Data"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private DataClass As New ProductDatabase()


    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim nodeParent As TreeNode
        Dim row As DataRow

        For Each row In DataClass.GetCategories.Rows

            ' Add the category node.
            nodeParent = treeDB.Nodes.Add(row(ProductDatabase.CategoryField.Name))
            nodeParent.ImageIndex = 0

            ' Store the disconnected category information.
            nodeParent.Tag = row

            ' Add a "dummy" node.
            nodeParent.Nodes.Add("*")

        Next

    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub treeDB_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles treeDB.BeforeExpand
        Dim nodeSelected, nodeChild As TreeNode
        nodeSelected = e.Node
        If nodeSelected.Nodes(0).Text = "*" Then
            nodeSelected.Nodes.Clear()
            Dim row As DataRow
            For Each row In DataClass.GetProductsInCategory(nodeSelected.Tag)
                nodeChild = nodeSelected.Nodes.Add(row(DataClass.ProductField.Name))

                ' Store the disconnected product information.
                nodeChild.Tag = row
                nodeChild.ImageIndex = 1
                nodeChild.SelectedImageIndex = 1
            Next
        End If
    End Sub

    Private Sub treeDB_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles treeDB.AfterSelect
        lblInfo.Text = DataClass.GetDisplayText(e.Node.Tag)
    End Sub

End Class

Public Class ProductDatabase

    Public Class Tables
        Public Const Product As String = "Products"
        Public Const Category As String = "Categories"
    End Class

    Public Class ProductField
        Public Const Name As String = "ModelName"
        Public Const Description As String = "Description"
    End Class

    Public Class CategoryField
        Public Const Name As String = "CategoryName"
    End Class

    Private dsStore As DataSet
    Dim relCategoryProduct As DataRelation

    Public Sub New()
        dsStore = New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")

        ' Define the relation.
        relCategoryProduct = New DataRelation("Prod_Cat", dsStore.Tables("Categories").Columns("CategoryID"), dsStore.Tables("Products").Columns("CategoryID"))
        dsStore.Relations.Add(relCategoryProduct)
    End Sub

    Public Function GetCategories() As DataTable
        Return dsStore.Tables("Categories")
    End Function

    Public Function GetProductsInCategory(ByVal rowParent As DataRow) As DataRow()
        Return rowParent.GetChildRows(relCategoryProduct)
    End Function

    Public Function GetDisplayText(ByVal row As DataRow) As String
        Dim Text As String
        Select Case row.Table.TableName
            Case Tables.Product
                Text = "ID: " & row(0) & vbNewLine
                Text &= "Name: " & row(ProductField.Name) & vbNewLine & vbNewLine
                Text &= row(ProductField.Description)
        End Select
        Return Text

    End Function
End Class