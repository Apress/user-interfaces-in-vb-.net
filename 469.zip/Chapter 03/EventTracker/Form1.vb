Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt As System.Windows.Forms.TextBox
    Friend WithEvents pic As System.Windows.Forms.PictureBox
    Friend WithEvents lstLog As System.Windows.Forms.ListBox
    Friend WithEvents cmd As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txt = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstLog = New System.Windows.Forms.ListBox()
        Me.pic = New System.Windows.Forms.PictureBox()
        Me.cmd = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt
        '
        Me.txt.Location = New System.Drawing.Point(156, 20)
        Me.txt.Name = "txt"
        Me.txt.Size = New System.Drawing.Size(192, 21)
        Me.txt.TabIndex = 1
        Me.txt.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Test keyboard events here:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(20, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Test mouse events here:"
        '
        'lstLog
        '
        Me.lstLog.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.lstLog.IntegralHeight = False
        Me.lstLog.Location = New System.Drawing.Point(8, 160)
        Me.lstLog.Name = "lstLog"
        Me.lstLog.Size = New System.Drawing.Size(384, 212)
        Me.lstLog.TabIndex = 0
        '
        'pic
        '
        Me.pic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pic.Location = New System.Drawing.Point(156, 48)
        Me.pic.Name = "pic"
        Me.pic.Size = New System.Drawing.Size(192, 48)
        Me.pic.TabIndex = 3
        Me.pic.TabStop = False
        '
        'cmd
        '
        Me.cmd.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmd.Location = New System.Drawing.Point(156, 100)
        Me.cmd.Name = "cmd"
        Me.cmd.Size = New System.Drawing.Size(88, 28)
        Me.cmd.TabIndex = 4
        Me.cmd.Text = "Button1"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 24)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Label3"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.Label1, Me.pic, Me.txt, Me.cmd, Me.Label2})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Location = New System.Drawing.Point(8, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(384, 148)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(92, 108)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 16)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "And here:"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(400, 378)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.Label3, Me.lstLog})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Event Tracker"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub txt_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt.KeyDown
        Log("Key Down: " & e.KeyCode & e.KeyValue)
    End Sub

    Private Sub txt_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt.KeyUp
        Log("Key Up: " & e.KeyCode & e.KeyValue & " Text is: " & txt.Text)
    End Sub

    Private Sub txt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt.TextChanged
        Log("Changed: " & " Text is: " & txt.Text)
    End Sub


    Private Sub txt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt.KeyPress
        Log("Key Press: " & e.KeyChar)

    End Sub

    Private Sub pic_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles pic.MouseEnter, cmd.MouseEnter
        Log("Mouse Enter")
    End Sub

    Private Sub pic_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pic.MouseMove
        'log("Mouse Move: " 
    End Sub

    Private Sub pic_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles pic.MouseHover, cmd.MouseHover
        Log("Mouse Hover")
    End Sub

    Private Sub pic_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pic.MouseDown, cmd.MouseDown
        Log("Mouse Down: X=" & e.X & "Y=" & e.Y & " Button=" & e.Button.ToString)
    End Sub

    Private Sub pic_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pic.MouseUp, cmd.MouseUp
        Log("Mouse Up: X=" & e.X & "Y=" & e.Y & " Button=" & e.Button.ToString)
    End Sub

    Private Sub pic_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles pic.Click, cmd.Click
        Log("Click")
    End Sub

    Private Sub pic_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles pic.DoubleClick
        Log("Double Click")
    End Sub

    Private Sub pic_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles pic.MouseLeave
        Log("Mouse Leave")
    End Sub


    Private Sub Log(ByVal data As String)
        lstLog.Items.Add(data)
        Dim ItemsPerPage As Integer = lstLog.Height \ lstLog.ItemHeight
        lstLog.TopIndex = lstLog.Items.Count - ItemsPerPage
    End Sub



End Class
