Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents imagesToolBar As System.Windows.Forms.ImageList
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ToolBarButton10 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBar2 As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    Friend WithEvents imagesLarge As System.Windows.Forms.ImageList
    Friend WithEvents ToolBar3 As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton8 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton9 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton12 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBar4 As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton13 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton16 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton()
        Me.imagesToolBar = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolBarButton10 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBar2 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton()
        Me.imagesLarge = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolBar3 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton8 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton9 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton12 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBar4 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton13 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton16 = New System.Windows.Forms.ToolBarButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'ToolBar1
        '
        Me.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton10})
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.imagesToolBar
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(304, 39)
        Me.ToolBar1.TabIndex = 0
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.Text = "One"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 1
        Me.ToolBarButton2.Text = "Two"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 2
        Me.ToolBarButton3.Text = "Three"
        '
        'imagesToolBar
        '
        Me.imagesToolBar.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imagesToolBar.ImageSize = New System.Drawing.Size(16, 16)
        Me.imagesToolBar.ImageStream = CType(resources.GetObject("imagesToolBar.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imagesToolBar.TransparentColor = System.Drawing.Color.Transparent
        '
        'Label1
        '
        Me.Label1.ForeColor = System.Drawing.Color.Navy
        Me.Label1.Location = New System.Drawing.Point(128, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Flat Buttons"
        '
        'ToolBarButton10
        '
        Me.ToolBarButton10.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBar2
        '
        Me.ToolBar2.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar2.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton7})
        Me.ToolBar2.DropDownArrows = True
        Me.ToolBar2.ImageList = Me.imagesToolBar
        Me.ToolBar2.Location = New System.Drawing.Point(0, 39)
        Me.ToolBar2.Name = "ToolBar2"
        Me.ToolBar2.ShowToolTips = True
        Me.ToolBar2.Size = New System.Drawing.Size(304, 25)
        Me.ToolBar2.TabIndex = 3
        Me.ToolBar2.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 0
        Me.ToolBarButton4.Text = "One"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 1
        Me.ToolBarButton5.Text = "Two"
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 2
        Me.ToolBarButton6.Text = "Three"
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'imagesLarge
        '
        Me.imagesLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imagesLarge.ImageSize = New System.Drawing.Size(32, 32)
        Me.imagesLarge.ImageStream = CType(resources.GetObject("imagesLarge.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imagesLarge.TransparentColor = System.Drawing.Color.Transparent
        '
        'ToolBar3
        '
        Me.ToolBar3.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar3.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton8, Me.ToolBarButton9, Me.ToolBarButton12})
        Me.ToolBar3.DropDownArrows = True
        Me.ToolBar3.ImageList = Me.imagesToolBar
        Me.ToolBar3.Location = New System.Drawing.Point(0, 64)
        Me.ToolBar3.Name = "ToolBar3"
        Me.ToolBar3.ShowToolTips = True
        Me.ToolBar3.Size = New System.Drawing.Size(304, 25)
        Me.ToolBar3.TabIndex = 4
        Me.ToolBar3.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'ToolBarButton8
        '
        Me.ToolBarButton8.ImageIndex = 0
        Me.ToolBarButton8.Pushed = True
        Me.ToolBarButton8.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.ToolBarButton8.Text = "One"
        '
        'ToolBarButton9
        '
        Me.ToolBarButton9.ImageIndex = 1
        Me.ToolBarButton9.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.ToolBarButton9.Text = "Two"
        '
        'ToolBarButton12
        '
        Me.ToolBarButton12.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBar4
        '
        Me.ToolBar4.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar4.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton13, Me.ToolBarButton16})
        Me.ToolBar4.DropDownArrows = True
        Me.ToolBar4.ImageList = Me.imagesToolBar
        Me.ToolBar4.Location = New System.Drawing.Point(0, 89)
        Me.ToolBar4.Name = "ToolBar4"
        Me.ToolBar4.ShowToolTips = True
        Me.ToolBar4.Size = New System.Drawing.Size(304, 25)
        Me.ToolBar4.TabIndex = 5
        Me.ToolBar4.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'ToolBarButton13
        '
        Me.ToolBarButton13.DropDownMenu = Me.ContextMenu1
        Me.ToolBarButton13.ImageIndex = 0
        Me.ToolBarButton13.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton
        Me.ToolBarButton13.Text = "One"
        '
        'ToolBarButton16
        '
        Me.ToolBarButton16.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'Label2
        '
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(192, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Text on Right"
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.Color.Navy
        Me.Label3.Location = New System.Drawing.Point(136, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Toggle Buttons"
        '
        'Label4
        '
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(104, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Drop-Down Button"
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.Text = "Menu 1"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "Menu 2"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.Text = "Menu 3"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(304, 182)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.Label3, Me.Label2, Me.ToolBar4, Me.ToolBar3, Me.ToolBar2, Me.Label1, Me.ToolBar1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "ToolBar Example"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class



