Public Class ListViewExample
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents cmdFillList As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents optSmallIcon As System.Windows.Forms.RadioButton
    Friend WithEvents optLargeIcon As System.Windows.Forms.RadioButton
    Friend WithEvents optDetails As System.Windows.Forms.RadioButton
    Friend WithEvents optList As System.Windows.Forms.RadioButton
    Friend WithEvents imagesLarge As System.Windows.Forms.ImageList
    Friend WithEvents imagesSmall As System.Windows.Forms.ImageList
    Friend WithEvents listAuthors As System.Windows.Forms.ListView
    Private components As System.ComponentModel.IContainer

    'Required by the Windows Form Designer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ListViewExample))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.optLargeIcon = New System.Windows.Forms.RadioButton()
        Me.optList = New System.Windows.Forms.RadioButton()
        Me.optDetails = New System.Windows.Forms.RadioButton()
        Me.optSmallIcon = New System.Windows.Forms.RadioButton()
        Me.listAuthors = New System.Windows.Forms.ListView()
        Me.imagesSmall = New System.Windows.Forms.ImageList(Me.components)
        Me.cmdFillList = New System.Windows.Forms.Button()
        Me.imagesLarge = New System.Windows.Forms.ImageList(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.optLargeIcon, Me.optList, Me.optDetails, Me.optSmallIcon})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(276, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(104, 132)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "View"
        '
        'optLargeIcon
        '
        Me.optLargeIcon.Checked = True
        Me.optLargeIcon.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.optLargeIcon.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optLargeIcon.Location = New System.Drawing.Point(16, 48)
        Me.optLargeIcon.Name = "optLargeIcon"
        Me.optLargeIcon.Size = New System.Drawing.Size(76, 16)
        Me.optLargeIcon.TabIndex = 0
        Me.optLargeIcon.TabStop = True
        Me.optLargeIcon.Text = "LargeIcon"
        '
        'optList
        '
        Me.optList.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.optList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optList.Location = New System.Drawing.Point(16, 96)
        Me.optList.Name = "optList"
        Me.optList.Size = New System.Drawing.Size(56, 16)
        Me.optList.TabIndex = 0
        Me.optList.Text = "List"
        '
        'optDetails
        '
        Me.optDetails.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.optDetails.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optDetails.Location = New System.Drawing.Point(16, 72)
        Me.optDetails.Name = "optDetails"
        Me.optDetails.Size = New System.Drawing.Size(72, 16)
        Me.optDetails.TabIndex = 0
        Me.optDetails.Text = "Details"
        '
        'optSmallIcon
        '
        Me.optSmallIcon.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.optSmallIcon.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSmallIcon.Location = New System.Drawing.Point(16, 24)
        Me.optSmallIcon.Name = "optSmallIcon"
        Me.optSmallIcon.Size = New System.Drawing.Size(72, 16)
        Me.optSmallIcon.TabIndex = 0
        Me.optSmallIcon.Text = "SmallIcon"
        '
        'listAuthors
        '
        Me.listAuthors.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.listAuthors.AllowColumnReorder = True
        Me.listAuthors.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.listAuthors.GridLines = True
        Me.listAuthors.HoverSelection = True
        Me.listAuthors.Location = New System.Drawing.Point(8, 8)
        Me.listAuthors.Name = "listAuthors"
        Me.listAuthors.Size = New System.Drawing.Size(260, 332)
        Me.listAuthors.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.listAuthors.TabIndex = 0
        '
        'imagesSmall
        '
        Me.imagesSmall.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imagesSmall.ImageSize = New System.Drawing.Size(16, 16)
        Me.imagesSmall.ImageStream = CType(resources.GetObject("imagesSmall.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imagesSmall.TransparentColor = System.Drawing.Color.Transparent
        '
        'cmdFillList
        '
        Me.cmdFillList.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdFillList.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdFillList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFillList.Location = New System.Drawing.Point(276, 152)
        Me.cmdFillList.Name = "cmdFillList"
        Me.cmdFillList.Size = New System.Drawing.Size(104, 24)
        Me.cmdFillList.TabIndex = 1
        Me.cmdFillList.Text = "Fill List"
        '
        'imagesLarge
        '
        Me.imagesLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imagesLarge.ImageSize = New System.Drawing.Size(32, 32)
        Me.imagesLarge.ImageStream = CType(resources.GetObject("imagesLarge.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imagesLarge.TransparentColor = System.Drawing.Color.Transparent
        '
        'ListViewExample
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(388, 349)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.cmdFillList, Me.listAuthors})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ListViewExample"
        Me.Text = "ListView Example"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub cmdFillList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFillList.Click

        listAuthors.BeginUpdate()

        Dim dt As DataTable = StoreDB.GetProducts()
        Dim dr As DataRow

        listAuthors.SmallImageList = imagesSmall
        listAuthors.LargeImageList = imagesLarge
        For Each dr In dt.Rows
            Dim listItem As New ListViewItem(dr("ModelName").ToString)
            listItem.ImageIndex = 0

            ' Add sub-items for Details view.
            listItem.SubItems.Add(dr("ProductID"))
            listItem.SubItems.Add(dr("Description"))

            listAuthors.Items.Add(listItem)
        Next

        ' Add column headers for Details view.
        listAuthors.Columns.Add("Product", 100, HorizontalAlignment.Left)
        listAuthors.Columns.Add("ID", 100, HorizontalAlignment.Left)
        listAuthors.Columns.Add("Description", 100, HorizontalAlignment.Left)

        listAuthors.EndUpdate()
    End Sub

    Private Sub NewView(ByVal sender As System.Object, ByVal e As System.EventArgs) _
 Handles optSmallIcon.CheckedChanged, optDetails.CheckedChanged, _
 optLargeIcon.CheckedChanged, optList.CheckedChanged

        listAuthors.View = CType(sender, Control).Tag
        Me.Text = "Using View: " & listAuthors.View.ToString

    End Sub


    Private Sub ListViewExample_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        optLargeIcon.Tag = View.LargeIcon
        optSmallIcon.Tag = View.SmallIcon
        optDetails.Tag = View.Details
        optList.Tag = View.List
        Call cmdFillList_Click(Nothing, Nothing)
    End Sub


    Private Sub listAuthors_ColumnClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs) Handles listAuthors.ColumnClick
        listAuthors.ListViewItemSorter = New CompareListViewItems(e.Column)
        listAuthors.Sort()
    End Sub
End Class

Public Class CompareListViewItems
    Implements IComparer

    Public ReadOnly Column As Integer

    Public Sub New(ByVal columnIndex As Integer)
        Column = columnIndex
    End Sub

    Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
        Dim ListX As ListViewItem = CType(x, ListViewItem)
        Dim ListY As ListViewItem = CType(y, ListViewItem)

        ' Sort using second column.
        ' The comparison is alphabetic, although you could convert
        ' the value to a number to perform a numeric comparisor.
        If ListX.SubItems(Column).Text > ListY.SubItems(Column).Text Then
            Return 1
        ElseIf ListX.SubItems(Column).Text = ListY.SubItems(Column).Text Then
            Return 0
        Else
            Return -1
        End If

    End Function
End Class

Public Class StoreDB

    Public Shared Function GetProducts() As DataTable
        Dim dsStore As New DataSet()

        dsStore.ReadXmlSchema(Application.StartupPath & "\store.xsd")
        dsStore.ReadXml(Application.StartupPath & "\store.xml")

        Return dsStore.Tables("Products")
    End Function


End Class