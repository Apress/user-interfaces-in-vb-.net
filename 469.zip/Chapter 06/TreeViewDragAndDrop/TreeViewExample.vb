Public Class TreeViewExample
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents treeOne As System.Windows.Forms.TreeView
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents treeTwo As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.treeOne = New System.Windows.Forms.TreeView()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.treeTwo = New System.Windows.Forms.TreeView()
        Me.SuspendLayout()
        '
        'treeOne
        '
        Me.treeOne.Dock = System.Windows.Forms.DockStyle.Left
        Me.treeOne.HideSelection = False
        Me.treeOne.ImageIndex = -1
        Me.treeOne.Location = New System.Drawing.Point(5, 5)
        Me.treeOne.Name = "treeOne"
        Me.treeOne.SelectedImageIndex = -1
        Me.treeOne.Size = New System.Drawing.Size(236, 351)
        Me.treeOne.TabIndex = 0
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(241, 5)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(3, 351)
        Me.Splitter1.TabIndex = 2
        Me.Splitter1.TabStop = False
        '
        'treeTwo
        '
        Me.treeTwo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.treeTwo.HideSelection = False
        Me.treeTwo.ImageIndex = -1
        Me.treeTwo.Location = New System.Drawing.Point(244, 5)
        Me.treeTwo.Name = "treeTwo"
        Me.treeTwo.SelectedImageIndex = -1
        Me.treeTwo.Size = New System.Drawing.Size(271, 351)
        Me.treeTwo.TabIndex = 3
        '
        'TreeViewExample
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(520, 366)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.treeTwo, Me.Splitter1, Me.treeOne})
        Me.DockPadding.Bottom = 10
        Me.DockPadding.Left = 5
        Me.DockPadding.Right = 5
        Me.DockPadding.Top = 5
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "TreeViewExample"
        Me.Text = "TreeView Example"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub TreeViewExample_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim node As TreeNode

        node = treeOne.Nodes.Add("Fruits")
        node.Nodes.Add("Apple")
        node.Nodes.Add("Peach")
        node.Expand()

        node = treeTwo.Nodes.Add("Vegetables")
        node.Nodes.Add("Tomato")
        node.Nodes.Add("Eggplant")
        node.Expand()

        treeTwo.AllowDrop = True
        treeOne.AllowDrop = True

    End Sub

    Private Sub treeOne_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles treeOne.MouseDown, treeTwo.MouseDown

        ' Get the tree.
        Dim tree As TreeView = CType(sender, TreeView)

        ' Get the node underneath the mouse.
        Dim node As TreeNode
        node = tree.GetNodeAt(e.X, e.Y)
        tree.SelectedNode = node

        ' Start the drag-and-drop operation with a cloned copy of the node.
        If Not node Is Nothing Then
            tree.DoDragDrop(node.Clone(), DragDropEffects.Copy)
        End If

    End Sub

    Private Sub treeTwo_DragOver(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles treeOne.DragOver, treeTwo.DragOver

        ' Get the tree.
        Dim tree As TreeView = CType(sender, TreeView)

        ' Drag and drop denied by default.
        e.Effect = DragDropEffects.None

        ' Is it a valid format?
        If Not e.Data.GetData(GetType(TreeNode)) Is Nothing Then

            ' Get the screen point.
            Dim pt As New Point(e.X, e.Y)

            ' Convert to a point in the TreeView's coordinate system.
            pt = tree.PointToClient(pt)

            ' Is the mouse over a valid node?
            Dim node As TreeNode = tree.GetNodeAt(pt)
            If Not node Is Nothing Then
                e.Effect = DragDropEffects.Copy
                tree.SelectedNode = node
            End If

        End If

    End Sub

    Private Sub treeTwo_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles treeOne.DragDrop, treeTwo.DragDrop

        ' Get the tree.
        Dim tree As TreeView = CType(sender, TreeView)

        ' Get the screen point.
        Dim pt As New Point(e.X, e.Y)

        ' Convert to a point in the TreeView's coordinate system.
        pt = tree.PointToClient(pt)

        ' Get the node underneath the mouse.
        Dim node As TreeNode = tree.GetNodeAt(pt)

        ' Add a child node.
        node.Nodes.Add(e.Data.GetData(GetType(TreeNode)))

        ' Show the newly added node if it is not already visible.
        node.Expand()
    End Sub



End Class
