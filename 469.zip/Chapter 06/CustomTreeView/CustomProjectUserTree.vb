Public Class CustomProjectUserTree
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents imagesTree As System.Windows.Forms.ImageList
    Private components As System.ComponentModel.IContainer
    Friend WithEvents tree As CustomTreeView.ProjectTree
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(CustomProjectUserTree))
        Me.imagesTree = New System.Windows.Forms.ImageList(Me.components)
        Me.tree = New CustomTreeView.ProjectTree()
        Me.SuspendLayout()
        '
        'imagesTree
        '
        Me.imagesTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imagesTree.ImageSize = New System.Drawing.Size(16, 16)
        Me.imagesTree.ImageStream = CType(resources.GetObject("imagesTree.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imagesTree.TransparentColor = System.Drawing.Color.Transparent
        '
        'tree
        '
        Me.tree.ImageList = Me.imagesTree
        Me.tree.Location = New System.Drawing.Point(8, 8)
        Me.tree.Name = "tree"
        Me.tree.Scrollable = False
        Me.tree.Size = New System.Drawing.Size(368, 288)
        Me.tree.TabIndex = 0
        '
        'CustomProjectUserTree
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(384, 310)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.tree})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "CustomProjectUserTree"
        Me.Text = "ProjectUser Tree"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub CustomProjectUserTree_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

   
        tree.AddProject("Migration to .NET", ProjectTree.StatusType.InProgress)
        tree.AddProject("Revamp pricing site", ProjectTree.StatusType.Unassigned)
        tree.AddProject("Prepare L-DAP feasibility report", ProjectTree.StatusType.Unassigned)
        tree.AddProject("Update E201-G to Windows XP", ProjectTree.StatusType.Closed)
        tree.AddProject("Annual meeting", ProjectTree.StatusType.Closed)


    End Sub

 
End Class

Public Class ProjectTree
    Inherits TreeView

    ' Use an enumeration to represent the three types of nodes.
    ' Specific numbers correspond to the database field code.
    Public Enum StatusType
        Unassigned = 101
        InProgress = 102
        Closed = 103
    End Enum

    ' Store references to the three main node branches.
    Private nodeUnassigned As New TreeNode("Unassigned", 0, 0)
    Private nodeInProgress As New TreeNode("In Progress", 1, 1)
    Private nodeClosed As New TreeNode("Closed", 2, 2)

    ' Add the main level of nodes when the control is instantiated.
    Public Sub New()
        MyBase.New()
        MyBase.Nodes.Clear()
        If Me.DesignMode = False Then
            MyBase.Nodes.Add(nodeUnassigned)
            MyBase.Nodes.Add(nodeInProgress)
            MyBase.Nodes.Add(nodeClosed)
        End If
    End Sub

    ' Provide a specialized method the client can use to add nodes.
    Public Sub AddProject(ByVal name As String, ByVal status As StatusType)
        Dim nodeNew As New TreeNode(name, 3, 4)
        nodeNew.Tag = status

        Select Case status
            Case StatusType.Unassigned
                nodeUnassigned.Nodes.Add(nodeNew)
            Case StatusType.InProgress
                nodeInProgress.Nodes.Add(nodeNew)
            Case StatusType.Closed
                nodeClosed.Nodes.Add(nodeNew)
        End Select
    End Sub

End Class
