Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lnkBuy As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkWebSite As System.Windows.Forms.LinkLabel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lnkBuy = New System.Windows.Forms.LinkLabel()
        Me.lnkWebSite = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'lnkBuy
        '
        Me.lnkBuy.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lnkBuy.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.lnkBuy.Location = New System.Drawing.Point(16, 60)
        Me.lnkBuy.Name = "lnkBuy"
        Me.lnkBuy.Size = New System.Drawing.Size(244, 48)
        Me.lnkBuy.TabIndex = 3
        Me.lnkBuy.Text = "Buy it at Amazon.com or Barnes and Noble."
        '
        'lnkWebSite
        '
        Me.lnkWebSite.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lnkWebSite.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.lnkWebSite.Location = New System.Drawing.Point(16, 16)
        Me.lnkWebSite.Name = "lnkWebSite"
        Me.lnkWebSite.Size = New System.Drawing.Size(248, 36)
        Me.lnkWebSite.TabIndex = 2
        Me.lnkWebSite.Text = "See www.prosetech.com for more information."
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 150)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lnkBuy, Me.lnkWebSite})
        Me.Name = "Form1"
        Me.Text = "Link Examples"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub lnkBuy_LinkClicked(ByVal sender As Object, _
      ByVal e As LinkLabelLinkClickedEventArgs) Handles lnkBuy.LinkClicked, _
      lnkWebSite.LinkClicked

        e.Link.Visited = True
        System.Diagnostics.Process.Start(CType(e.Link.LinkData, String))

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lnkBuy.Links.Add(10, 10, "http://www.amazon.com")
        lnkBuy.Links.Add(24, 16, "http://www.bn.com")
        lnkWebSite.Links.Add(4, 17, "http://www.prosetech.com")

    End Sub
End Class
