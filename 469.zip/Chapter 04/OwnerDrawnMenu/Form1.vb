Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOpen As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSave As System.Windows.Forms.MenuItem
    Friend WithEvents imgMenu As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuNew = New System.Windows.Forms.MenuItem()
        Me.mnuOpen = New System.Windows.Forms.MenuItem()
        Me.mnuSave = New System.Windows.Forms.MenuItem()
        Me.imgMenu = New System.Windows.Forms.ImageList(Me.components)
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuNew, Me.mnuOpen, Me.mnuSave})
        Me.mnuFile.Text = "File"
        '
        'mnuNew
        '
        Me.mnuNew.Index = 0
        Me.mnuNew.OwnerDraw = True
        Me.mnuNew.Text = "New"
        '
        'mnuOpen
        '
        Me.mnuOpen.Index = 1
        Me.mnuOpen.OwnerDraw = True
        Me.mnuOpen.Text = "Open"
        '
        'mnuSave
        '
        Me.mnuSave.Index = 2
        Me.mnuSave.OwnerDraw = True
        Me.mnuSave.Text = "Save"
        '
        'imgMenu
        '
        Me.imgMenu.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgMenu.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgMenu.ImageStream = CType(resources.GetObject("imgMenu.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgMenu.TransparentColor = System.Drawing.Color.Transparent
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Owner-Drawn Menu"

    End Sub

#End Region



    Private Sub mnu_MeasureItem(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MeasureItemEventArgs) Handles mnuNew.MeasureItem, mnuOpen.MeasureItem, mnuSave.MeasureItem

        ' Retrieve current item.
        Dim mnuItem As MenuItem = CType(sender, MenuItem)

        Dim MenuFont As New Font("Tahoma", 8)

        ' Measure size needed to display text.
        ' We add 30 pixels to the width to allow a generous spacing for the image.
        e.ItemHeight = e.Graphics.MeasureString(mnuItem.Text, MenuFont).Height + 5
        e.ItemWidth = e.Graphics.MeasureString(mnuItem.Text, MenuFont).Width + 30

    End Sub


    Private Sub mnu_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles mnuNew.DrawItem, mnuOpen.DrawItem, mnuSave.DrawItem
        ' Retrieve current item.
        Dim mnuItem As MenuItem = CType(sender, MenuItem)

        ' Determine whether a highlighted background is needed.
        ' Note that bitwise comparison is required to evaluated the state,
        '  as several state flags may be set in conjunction.
        If e.State And DrawItemState.Selected = DrawItemState.Selected Then
            e.DrawBackground()
        End If

        ' Retrieve the image from an ImageList control.
        Dim MenuImage As Image = imgMenu.Images(mnuItem.Index)

        ' Draw the image.
        e.Graphics.DrawImage(MenuImage, e.Bounds.Left + 3, e.Bounds.Top + 2)

        ' Draw the text with the supplied colors and in the set region.
        e.Graphics.DrawString(mnuItem.Text, e.Font, New SolidBrush(e.ForeColor), e.Bounds.Left + 25, e.Bounds.Top + 3)
    End Sub

  
End Class
