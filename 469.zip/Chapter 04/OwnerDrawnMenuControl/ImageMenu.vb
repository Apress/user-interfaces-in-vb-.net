
Public Class ImageMenuItem
    Inherits MenuItem

    Private _Font As Font
    Private _ForeColor As Color
    Private _Image As Image

    Public Property Font() As Font
        Get
            Return _Font
        End Get
        Set(ByVal Value As Font)
            _Font = Value
        End Set
    End Property

    Public Property Image() As Image
        Get
            Return _Image
        End Get
        Set(ByVal Value As Image)
            _Image = Value
        End Set
    End Property

    Public Property ForeColor() As Color
        Get
            Return _ForeColor
        End Get
        Set(ByVal Value As Color)
            _ForeColor = Value
        End Set
    End Property

    Public Sub New(ByVal Text As String, ByVal Font As Font, ByVal Image As Image, ByVal ForeColor As Color)
        MyBase.New(Text)
        Me.Font = Font
        Me.Image = Image
        Me.ForeColor = ForeColor
        Me.OwnerDraw = True
    End Sub

    Public Sub New(ByVal Text As String, ByVal Image As Image)
        MyBase.New(Text)
        Me.Font = New Font("Tahoma", 8)
        Me.Image = Image
        Me.ForeColor = SystemColors.MenuText
        Me.OwnerDraw = True
    End Sub

    Protected Overrides Sub OnMeasureItem(ByVal e As System.Windows.Forms.MeasureItemEventArgs)
        MyBase.OnMeasureItem(e)
        ' Measure size needed to display text.
        ' We add 30 pixels to the width to allow a generous spacing for the image.
        e.ItemHeight = e.Graphics.MeasureString(Me.Text, Me.Font).Height + 5
        e.ItemWidth = e.Graphics.MeasureString(Me.Text, Me.Font).Width + 30

    End Sub


    Protected Overrides Sub OnDrawItem(ByVal e As System.Windows.Forms.DrawItemEventArgs)
        MyBase.OnDrawItem(e)
        ' Determine whether a highlighted background is needed.
        Dim TextColor As Color
        If Me.Enabled = False Then
            TextColor = SystemColors.GrayText
        ElseIf e.State And DrawItemState.Selected = DrawItemState.Selected Then
            e.DrawBackground()
            TextColor = e.ForeColor
        Else
            TextColor = Me.ForeColor
        End If

        ' Draw the image.
        If Not Image Is Nothing Then
            If Me.Enabled = False Then
                ControlPaint.DrawImageDisabled(e.Graphics, Image, e.Bounds.Left + 3, e.Bounds.Top + 2, SystemColors.Menu)
            Else
                e.Graphics.DrawImage(Image, e.Bounds.Left + 3, e.Bounds.Top + 2)
            End If
        End If

        ' Draw the text with the supplied colors and in the set region.
        e.Graphics.DrawString(Me.Text, Me.Font, New SolidBrush(TextColor), e.Bounds.Left + 25, e.Bounds.Top + 3)
    End Sub
End Class


