Public Class ControlPalette
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents images As System.Windows.Forms.ImageList
    Friend WithEvents lblPictureOne As System.Windows.Forms.Label
    Friend WithEvents lblPictureTwo As System.Windows.Forms.Label
    Friend WithEvents lblPictureThree As System.Windows.Forms.Label
    Private components As System.ComponentModel.IContainer

    'Required by the Windows Form Designer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ControlPalette))
        Me.lblPictureThree = New System.Windows.Forms.Label()
        Me.images = New System.Windows.Forms.ImageList(Me.components)
        Me.lblPictureOne = New System.Windows.Forms.Label()
        Me.lblPictureTwo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblPictureThree
        '
        Me.lblPictureThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPictureThree.Image = CType(resources.GetObject("lblPictureThree.Image"), System.Drawing.Bitmap)
        Me.lblPictureThree.ImageIndex = 2
        Me.lblPictureThree.ImageList = Me.images
        Me.lblPictureThree.Location = New System.Drawing.Point(4, 108)
        Me.lblPictureThree.Name = "lblPictureThree"
        Me.lblPictureThree.Size = New System.Drawing.Size(56, 48)
        Me.lblPictureThree.TabIndex = 0
        '
        'images
        '
        Me.images.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.images.ImageSize = New System.Drawing.Size(16, 16)
        Me.images.ImageStream = CType(resources.GetObject("images.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.images.TransparentColor = System.Drawing.Color.Transparent
        '
        'lblPictureOne
        '
        Me.lblPictureOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPictureOne.Image = CType(resources.GetObject("lblPictureOne.Image"), System.Drawing.Bitmap)
        Me.lblPictureOne.ImageIndex = 0
        Me.lblPictureOne.ImageList = Me.images
        Me.lblPictureOne.Location = New System.Drawing.Point(4, 4)
        Me.lblPictureOne.Name = "lblPictureOne"
        Me.lblPictureOne.Size = New System.Drawing.Size(56, 48)
        Me.lblPictureOne.TabIndex = 0
        '
        'lblPictureTwo
        '
        Me.lblPictureTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPictureTwo.Image = CType(resources.GetObject("lblPictureTwo.Image"), System.Drawing.Bitmap)
        Me.lblPictureTwo.ImageIndex = 1
        Me.lblPictureTwo.ImageList = Me.images
        Me.lblPictureTwo.Location = New System.Drawing.Point(4, 56)
        Me.lblPictureTwo.Name = "lblPictureTwo"
        Me.lblPictureTwo.Size = New System.Drawing.Size(56, 48)
        Me.lblPictureTwo.TabIndex = 0
        '
        'ControlPalette
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(66, 160)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblPictureThree, Me.lblPictureTwo, Me.lblPictureOne})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "ControlPalette"
        Me.Text = "Pictures"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub lblPicture_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) _
     Handles lblPictureOne.MouseDown, lblPictureTwo.MouseDown, lblPictureThree.MouseDown
        Dim lbl As Label = CType(sender, Label)
        lbl.DoDragDrop(lbl.Image, DragDropEffects.Copy)

    End Sub


End Class
