Public Class FakeDragAndDrop
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents lblDragger As System.Windows.Forms.Label
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FakeDragAndDrop))
        Me.lblDragger = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblDragger
        '
        Me.lblDragger.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDragger.Image = CType(resources.GetObject("lblDragger.Image"), System.Drawing.Bitmap)
        Me.lblDragger.Location = New System.Drawing.Point(40, 40)
        Me.lblDragger.Name = "lblDragger"
        Me.lblDragger.Size = New System.Drawing.Size(72, 56)
        Me.lblDragger.TabIndex = 1
        '
        'FakeDragAndDrop
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(232, 162)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblDragger})
        Me.Name = "FakeDragAndDrop"
        Me.Text = "Fake Drag And Drop"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub cmdDragger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    ' Keep track of when fake "drag and drop" mode is enabled.
    Private IsDragging As Boolean = False

    ' Store the location where the user clicked on the control.
    Private ClickOffsetX, ClickOffsetY As Integer

    ' Start dragging.
    Private Sub lblDragger_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblDragger.MouseDown
        IsDragging = True
        ClickOffsetX = e.X
        ClickOffsetY = e.Y
    End Sub

    ' End dragging.
    Private Sub lblDragger_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblDragger.MouseUp
        IsDragging = False
    End Sub

    ' Move the control (during dragging).
    Private Sub lblDragger_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblDragger.MouseMove
        If IsDragging = True Then
            ' The control coordinates are converted into form coordinates
            ' by adding the label position offset.
            ' The offset where the user clicked in the control is also
            ' accounted for. Otherwise, it looks like the top-left corner
            ' of the label is attached to the mouse.
            lblDragger.Left = e.X + lblDragger.Left - ClickOffsetX
            lblDragger.Top = e.Y + lblDragger.Top - ClickOffsetY
        End If
    End Sub
End Class
