Public Class DrawSquare
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents pnlSquares As System.Windows.Forms.StatusBarPanel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.StatusBar1 = New System.Windows.Forms.StatusBar()
        Me.pnlSquares = New System.Windows.Forms.StatusBarPanel()
        CType(Me.pnlSquares, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 244)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.pnlSquares})
        Me.StatusBar1.ShowPanels = True
        Me.StatusBar1.Size = New System.Drawing.Size(292, 22)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 0
        Me.StatusBar1.Text = "StatusBar1"
        '
        'pnlSquares
        '
        Me.pnlSquares.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.pnlSquares.Width = 292
        '
        'DrawSquare
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.StatusBar1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "DrawSquare"
        Me.Text = "DrawSquare"
        CType(Me.pnlSquares, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Squares As New ArrayList()

    Private Sub DrawSquare_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim DrawingPen As New Pen(Color.Red, 10)
        Dim Square As Rectangle
        For Each Square In Squares
            e.Graphics.DrawRectangle(DrawingPen, Square)
        Next
        pnlSquares.Text = " " & Squares.Count.ToString & " squares"
    End Sub

    Private Sub DrawSquare_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        If e.Button = MouseButtons.Left Then
            Dim Square As New Rectangle(e.X, e.Y, 20, 20)
            Squares.Add(Square)

            Me.Invalidate(Square)
        ElseIf e.Button = MouseButtons.Right Then
            Dim Square As Rectangle
            Dim SquareNumber As Integer
            For Each Square In Squares
                SquareNumber += 1
                If Square.Contains(e.X, e.Y) Then
                    MessageBox.Show("Point inside square #" & SquareNumber.ToString())
                End If
            Next
        End If
    End Sub


End Class
