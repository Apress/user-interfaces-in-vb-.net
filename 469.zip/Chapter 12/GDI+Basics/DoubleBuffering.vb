Public Class DoubleBuffering
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tmrRefresh As System.Windows.Forms.Timer
    Friend WithEvents chkDoubleBuffer As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrRefresh = New System.Windows.Forms.Timer(Me.components)
        Me.chkDoubleBuffer = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'tmrRefresh
        '
        Me.tmrRefresh.Interval = 10
        '
        'chkDoubleBuffer
        '
        Me.chkDoubleBuffer.BackColor = System.Drawing.Color.PowderBlue
        Me.chkDoubleBuffer.Location = New System.Drawing.Point(8, 8)
        Me.chkDoubleBuffer.Name = "chkDoubleBuffer"
        Me.chkDoubleBuffer.Size = New System.Drawing.Size(336, 16)
        Me.chkDoubleBuffer.TabIndex = 0
        Me.chkDoubleBuffer.Text = "Use Double Buffering"
        '
        'DoubleBuffering
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(436, 330)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkDoubleBuffer})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "DoubleBuffering"
        Me.Text = "DoubleBuffering"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DoubleBuffering_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tmrRefresh.Start()
    End Sub


    Private Sub DoubleBuffering_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint

        Dim g As Graphics
        Dim Drawing As Bitmap

        ' Check if double buffering is needed, and assign the GDI+ context.
        If chkDoubleBuffer.Checked Then
            Drawing = New Bitmap(Me.Width, Me.Height, e.Graphics)
            g = Graphics.FromImage(Drawing)
        Else
            g = e.Graphics
        End If

        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality

        ' Draw a rectangle.
        Dim DrawingPen As New Pen(Color.Black, 10)
        g.FillRectangle(Brushes.PowderBlue, New Rectangle(New Point(0, 0), Me.ClientSize))
        g.DrawEllipse(DrawingPen, 50, 50, 50 + ExtraSize, 50 + ExtraSize)

        ' If using double buffering, render the final image and dispose of it.
        If chkDoubleBuffer.Checked Then
            e.Graphics.DrawImageUnscaled(Drawing, 0, 0)
            g.Dispose()
        End If

    End Sub

    Private IsShrinking As Boolean
    Private ExtraSize As Single
    Private Sub tmrRefresh_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRefresh.Tick
        ' Change the circle dimensions.
        If IsShrinking Then
            ExtraSize -= 1
        Else
            ExtraSize += 1
        End If

        ' Change the sizing if needed.
        If ExtraSize > Me.Width - 150 Then
            IsShrinking = True
        ElseIf ExtraSize < 1 Then
            IsShrinking = False
        End If

        ' Repaint the form.
        Me.Invalidate()
    End Sub

    Protected Overrides Sub OnPaintBackground(ByVal pevent As System.Windows.Forms.PaintEventArgs)
        ' Do nothing.
    End Sub
End Class
