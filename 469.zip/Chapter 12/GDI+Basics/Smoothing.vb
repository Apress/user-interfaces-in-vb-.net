Public Class Smoothing
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents picNone As System.Windows.Forms.PictureBox
    Friend WithEvents picHighSpeed As System.Windows.Forms.PictureBox
    Friend WithEvents picAntialias As System.Windows.Forms.PictureBox
    Friend WithEvents picHighQuality As System.Windows.Forms.PictureBox
    Friend WithEvents grpNone As System.Windows.Forms.GroupBox
    Friend WithEvents grpHighSpeed As System.Windows.Forms.GroupBox
    Friend WithEvents grpAntiAlias As System.Windows.Forms.GroupBox
    Friend WithEvents grpHighQuality As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.picNone = New System.Windows.Forms.PictureBox()
        Me.grpNone = New System.Windows.Forms.GroupBox()
        Me.grpHighSpeed = New System.Windows.Forms.GroupBox()
        Me.picHighSpeed = New System.Windows.Forms.PictureBox()
        Me.grpAntiAlias = New System.Windows.Forms.GroupBox()
        Me.picAntialias = New System.Windows.Forms.PictureBox()
        Me.grpHighQuality = New System.Windows.Forms.GroupBox()
        Me.picHighQuality = New System.Windows.Forms.PictureBox()
        Me.grpNone.SuspendLayout()
        Me.grpHighSpeed.SuspendLayout()
        Me.grpAntiAlias.SuspendLayout()
        Me.grpHighQuality.SuspendLayout()
        Me.SuspendLayout()
        '
        'picNone
        '
        Me.picNone.Location = New System.Drawing.Point(8, 16)
        Me.picNone.Name = "picNone"
        Me.picNone.Size = New System.Drawing.Size(328, 64)
        Me.picNone.TabIndex = 0
        Me.picNone.TabStop = False
        '
        'grpNone
        '
        Me.grpNone.Controls.AddRange(New System.Windows.Forms.Control() {Me.picNone})
        Me.grpNone.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpNone.Location = New System.Drawing.Point(8, 8)
        Me.grpNone.Name = "grpNone"
        Me.grpNone.Size = New System.Drawing.Size(344, 85)
        Me.grpNone.TabIndex = 1
        Me.grpNone.TabStop = False
        Me.grpNone.Text = "None"
        '
        'grpHighSpeed
        '
        Me.grpHighSpeed.Controls.AddRange(New System.Windows.Forms.Control() {Me.picHighSpeed})
        Me.grpHighSpeed.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpHighSpeed.Location = New System.Drawing.Point(8, 96)
        Me.grpHighSpeed.Name = "grpHighSpeed"
        Me.grpHighSpeed.Size = New System.Drawing.Size(344, 85)
        Me.grpHighSpeed.TabIndex = 2
        Me.grpHighSpeed.TabStop = False
        Me.grpHighSpeed.Text = "HighSpeed"
        '
        'picHighSpeed
        '
        Me.picHighSpeed.Location = New System.Drawing.Point(8, 16)
        Me.picHighSpeed.Name = "picHighSpeed"
        Me.picHighSpeed.Size = New System.Drawing.Size(328, 64)
        Me.picHighSpeed.TabIndex = 0
        Me.picHighSpeed.TabStop = False
        '
        'grpAntiAlias
        '
        Me.grpAntiAlias.Controls.AddRange(New System.Windows.Forms.Control() {Me.picAntialias})
        Me.grpAntiAlias.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpAntiAlias.Location = New System.Drawing.Point(8, 184)
        Me.grpAntiAlias.Name = "grpAntiAlias"
        Me.grpAntiAlias.Size = New System.Drawing.Size(344, 85)
        Me.grpAntiAlias.TabIndex = 3
        Me.grpAntiAlias.TabStop = False
        Me.grpAntiAlias.Text = "AntiAlias"
        '
        'picAntialias
        '
        Me.picAntialias.Location = New System.Drawing.Point(8, 16)
        Me.picAntialias.Name = "picAntialias"
        Me.picAntialias.Size = New System.Drawing.Size(328, 64)
        Me.picAntialias.TabIndex = 0
        Me.picAntialias.TabStop = False
        '
        'grpHighQuality
        '
        Me.grpHighQuality.Controls.AddRange(New System.Windows.Forms.Control() {Me.picHighQuality})
        Me.grpHighQuality.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpHighQuality.Location = New System.Drawing.Point(8, 272)
        Me.grpHighQuality.Name = "grpHighQuality"
        Me.grpHighQuality.Size = New System.Drawing.Size(344, 85)
        Me.grpHighQuality.TabIndex = 4
        Me.grpHighQuality.TabStop = False
        Me.grpHighQuality.Text = "HighQuality"
        '
        'picHighQuality
        '
        Me.picHighQuality.Location = New System.Drawing.Point(8, 16)
        Me.picHighQuality.Name = "picHighQuality"
        Me.picHighQuality.Size = New System.Drawing.Size(328, 64)
        Me.picHighQuality.TabIndex = 0
        Me.picHighQuality.TabStop = False
        '
        'Smoothing
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(368, 374)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpHighQuality, Me.grpAntiAlias, Me.grpHighSpeed, Me.grpNone})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Smoothing"
        Me.Text = "Smoothing"
        Me.grpNone.ResumeLayout(False)
        Me.grpHighSpeed.ResumeLayout(False)
        Me.grpAntiAlias.ResumeLayout(False)
        Me.grpHighQuality.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub picNone_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picNone.Paint
        e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.None
        DrawEllipse(e.Graphics)
    End Sub

    Private Sub picHighSpeed_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picHighSpeed.Paint
        e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.HighSpeed
        DrawEllipse(e.Graphics)
    End Sub

    Private Sub picAntialias_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picAntialias.Paint
        e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.AntiAlias
        DrawEllipse(e.Graphics)
    End Sub

    Private Sub picHighQuality_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picHighQuality.Paint
        e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.HighQuality
        DrawEllipse(e.Graphics)
    End Sub

    Private Sub DrawEllipse(ByVal g As Graphics)
        Dim DrawingPen As New Pen(Color.Red, 5)
        g.DrawEllipse(DrawingPen, 10, 10, 300, 40)
    End Sub



End Class
