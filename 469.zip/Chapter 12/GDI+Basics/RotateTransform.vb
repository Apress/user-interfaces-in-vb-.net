Public Class RotateTransform
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'RotateTransform
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Name = "RotateTransform"
        Me.Text = "Rotate Transform"

    End Sub

#End Region


    Private Sub RotateTransform_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        ' Optimize text quality.
        e.Graphics.TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAliasGridFit

        ' Move origin to center of form so we can rotate around that.
        e.Graphics.TranslateTransform(Me.Width \ 2 - 30, Me.Height \ 2 - 30)
        
        DrawText(e.Graphics)
        e.Graphics.RotateTransform(45)
        DrawText(e.Graphics)
        e.Graphics.RotateTransform(75)
        DrawText(e.Graphics)
        e.Graphics.RotateTransform(160)
        DrawText(e.Graphics)
    End Sub

    Private Sub DrawText(ByVal g As Graphics)
        g.DrawString("Text", New Font("Verdana", 30, FontStyle.Bold), Brushes.Black, 0, 10)
    End Sub
End Class
