Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Status As ProgressBarUserControl.Progress
    Friend WithEvents cmdStart As System.Windows.Forms.Button
    Friend WithEvents tmrIncrementBar As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Status = New ProgressBarUserControl.Progress()
        Me.cmdStart = New System.Windows.Forms.Button()
        Me.tmrIncrementBar = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Status
        '
        Me.Status.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.Status.BackColor = System.Drawing.SystemColors.Control
        Me.Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Status.Location = New System.Drawing.Point(4, 16)
        Me.Status.Maximum = 100
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(284, 88)
        Me.Status.Step = 10
        Me.Status.TabIndex = 0
        Me.Status.X = ProgressBarUserControl.Progress.xx.a
        '
        'cmdStart
        '
        Me.cmdStart.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdStart.Location = New System.Drawing.Point(92, 140)
        Me.cmdStart.Name = "cmdStart"
        Me.cmdStart.Size = New System.Drawing.Size(108, 24)
        Me.cmdStart.TabIndex = 1
        Me.cmdStart.Text = "Start"
        '
        'tmrIncrementBar
        '
        Me.tmrIncrementBar.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(292, 174)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStart, Me.Status})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Progress Host"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub tmrIncrementBar_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrIncrementBar.Tick
        Status.PerformStep()
        If Status.Maximum = Status.Value Then tmrIncrementBar.Enabled = False
    End Sub

    Private Sub cmdStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStart.Click
        tmrIncrementBar.Enabled = False

        Status.Value = 0
        Status.Maximum = 20
        Status.Step = 1

        tmrIncrementBar.Enabled = True
    End Sub
End Class
