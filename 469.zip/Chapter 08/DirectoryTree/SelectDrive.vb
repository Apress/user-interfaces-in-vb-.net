Public Class SelectDrive
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstDrives As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstDrives = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstDrives
        '
        Me.lstDrives.Location = New System.Drawing.Point(8, 24)
        Me.lstDrives.Name = "lstDrives"
        Me.lstDrives.Size = New System.Drawing.Size(248, 173)
        Me.lstDrives.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Choose a Drive:"
        '
        'cmdClose
        '
        Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdClose.Location = New System.Drawing.Point(80, 224)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(104, 24)
        Me.cmdClose.TabIndex = 2
        Me.cmdClose.Text = "OK"
        '
        'SelectDrive
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(266, 256)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdClose, Me.Label1, Me.lstDrives})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SelectDrive"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Select Drive"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public DriveSelection As Char

    Private Sub SelectDrive_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Drives() As String = System.IO.Directory.GetLogicalDrives()
        lstDrives.DataSource = Drives

        ' Select the current drive.
        lstDrives.SelectedIndex = lstDrives.FindString(DriveSelection)

        ' Attach the event handler.
        ' This step is performed after the selected index is set,
        ' to prevent it from being overwritten as the list is built.
        AddHandler lstDrives.SelectedIndexChanged, AddressOf lstDrives_SelectedIndexChanged
    End Sub

    Private Sub lstDrives_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        DriveSelection = lstDrives.Text.Chars(0)
    End Sub

End Class
