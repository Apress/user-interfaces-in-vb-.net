Imports System.IO
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.Windows.Forms.Design
Imports System.Drawing.Design
Imports Microsoft.Win32

Public Class RegistryLicenseProvider
    Inherits LicenseProvider

    Public Overrides Function GetLicense(ByVal context As System.ComponentModel.LicenseContext, ByVal [type] As System.Type, ByVal instance As Object, ByVal allowExceptions As Boolean) As System.ComponentModel.License
        Dim Key As String

        If context.UsageMode = LicenseUsageMode.Runtime Then
            ' Try to find key in current context.
            Key = context.GetSavedLicenseKey(type, Nothing)
        End If

        ' Always look in the registry at design time.
        ' If the key wasn't found in the current context at runtime,
        ' we can also look in the registry.
        ' Another option might be to always allows the control at runtime,
        ' and just restrict it at design time.
        If Key = "" Then
            ' A debugging hint:
            MessageBox.Show("Performing registry lookup.", "RegistryLicenseProvider")

            Dim rk As RegistryKey
            rk = Registry.LocalMachine.OpenSubKey("Software\MyCompany\" & type.ToString())
            If Not rk Is Nothing Then
                Key = rk.GetValue("LicenseKey", "")
            End If

            ' Save key in current context.
            If Key <> "" Then context.SetSavedLicenseKey(type, Key)
        End If

        ' Check if key is valid.
        If Not IsValid(Key) Then
            If Not allowExceptions Then Throw New LicenseException(type)
        End If

        ' Return the license object.
        Return New CustomLicense(Key)
    End Function

    Private Function IsValid(ByVal key As String) As Boolean
        If key = "1234567890" Then
            Return True
        Else
            Return False
        End If
    End Function

End Class

Public Class CustomLicense
    Inherits License

    Private _Key As String
    Public Overrides ReadOnly Property LicenseKey() As String
        Get
            Return _Key
        End Get
    End Property

    Public Sub New(ByVal key As String)
        _Key = key
    End Sub
    Public Overrides Sub Dispose()
        ' This method must be overriden.
    End Sub
End Class


Public Class FileLicenseProvider
    Inherits LicFileLicenseProvider

    Protected Overrides Function IsKeyValid(ByVal key As String, ByVal [type] As System.Type) As Boolean

        Dim Code As Integer = Val(key.Substring(0, 3))
        If Code <> 0 Then
            If Math.IEEERemainder(Code, 7) = 0 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

End Class