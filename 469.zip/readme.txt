Using the Samples
-----------------

Samples are organized by chapter, and then by "application" or example name. You should open a project in Visual Studio .NET through the .sln (solution) file.

Note that Visual Studio .NET automatically creates various temporary and debugging files in the obj and bin sub-directory for each project. The actual uncompiled code is only the .vb files that are contained in the root project directory.

In addition, the root directory contains a file named WindowsXP.exe.manifest that you can use to enable Windows XP styles (provided you are running under WindowsXP). Simply rename this file to mach you application (as in MyApp.exe.manifest), place it in the same directory as the executable, and set the FlatStyle for any button controls to System.

An SQL database script is included for Chapter 11, which allows you to automatically install the tables required to test the dynamic menu example in SQL Server. The easiest way to use it is to start by manually creating a new database (ideally called Apress, so you won't need to modify the example). Next, use a tool like Query Analyzer to run the script. Typically you would open the file, type "USE Apress" at the
top (where Apress is the name of the database), and then execute the script.