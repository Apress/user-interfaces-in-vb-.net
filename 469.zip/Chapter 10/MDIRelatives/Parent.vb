Public Class Parent
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents cmdNew As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents imgButtons As System.Windows.Forms.ImageList
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCascade As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTileV As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTileH As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMinimizeAll As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Parent))
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.cmdNew = New System.Windows.Forms.ToolBarButton()
        Me.cmdClose = New System.Windows.Forms.ToolBarButton()
        Me.imgButtons = New System.Windows.Forms.ImageList(Me.components)
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.mnuCascade = New System.Windows.Forms.MenuItem()
        Me.mnuTileV = New System.Windows.Forms.MenuItem()
        Me.mnuTileH = New System.Windows.Forms.MenuItem()
        Me.mnuMinimizeAll = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'ToolBar1
        '
        Me.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdNew, Me.cmdClose})
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.imgButtons
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(292, 41)
        Me.ToolBar1.TabIndex = 3
        '
        'cmdNew
        '
        Me.cmdNew.ImageIndex = 0
        Me.cmdNew.Text = "New"
        '
        'cmdClose
        '
        Me.cmdClose.ImageIndex = 1
        Me.cmdClose.Text = "Close"
        '
        'imgButtons
        '
        Me.imgButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgButtons.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgButtons.ImageStream = CType(resources.GetObject("imgButtons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgButtons.TransparentColor = System.Drawing.Color.Transparent
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MdiList = True
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuCascade, Me.mnuTileV, Me.mnuTileH, Me.mnuMinimizeAll})
        Me.MenuItem1.Text = "Window"
        '
        'mnuCascade
        '
        Me.mnuCascade.Index = 0
        Me.mnuCascade.Text = "Cascase"
        '
        'mnuTileV
        '
        Me.mnuTileV.Index = 1
        Me.mnuTileV.Text = "Tile Vertical"
        '
        'mnuTileH
        '
        Me.mnuTileH.Index = 2
        Me.mnuTileH.Text = "Tile Horizontal"
        '
        'mnuMinimizeAll
        '
        Me.mnuMinimizeAll.Index = 3
        Me.mnuMinimizeAll.Text = "Minimize All"
        '
        'Parent
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(292, 241)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ToolBar1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "Parent"
        Me.Text = "MDI Parent"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private MdiCount As Integer
    Private Sub ToolBar1_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick
        If e.Button Is cmdNew Then
            Dim frmChild As New Child()
            frmChild.MdiParent = Me
            MdiCount += 1
            frmChild.Text = "MDI Child #" & MdiCount.ToString()
            frmChild.RefreshText(SynchronizedText)
            frmChild.Show()
        ElseIf e.Button Is cmdClose Then
            Me.ActiveMdiChild.Close()
        End If
    End Sub

    Private SynchronizedText As String = "text"

    Public Sub RefreshChildren(ByVal sender As Child, ByVal text As String)
        ' Store text for use when creating a child form, or if needed later.
        SynchronizedText = text

        ' Update children.
        Dim frm As Child
        For Each frm In Me.MdiChildren
            If Not frm Is sender Then
                frm.RefreshText(text)
            End If
        Next
    End Sub

    Private Sub mnuCascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
        Me.Text = "Cascade"
    End Sub

    Private Sub mnuTileV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTileV.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
        Me.Text = "TileVertical"
    End Sub

    Private Sub mnuTileH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTileH.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
        Me.Text = "TileHorizontal"
    End Sub


    Private Sub mnuMinimizeAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMinimizeAll.Click
        Dim frm As Form
        For Each frm In Me.MdiChildren
            frm.WindowState = FormWindowState.Minimized
        Next
        Me.Text = "Minimize All"
    End Sub

End Class
