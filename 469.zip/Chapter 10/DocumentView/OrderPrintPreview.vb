Imports System.Drawing.Printing

Public Class OrderPrintPreview
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Preview As System.Windows.Forms.PrintPreviewControl
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Preview = New System.Windows.Forms.PrintPreviewControl()
        Me.SuspendLayout()
        '
        'Preview
        '
        Me.Preview.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.Preview.AutoZoom = False
        Me.Preview.Location = New System.Drawing.Point(4, 0)
        Me.Preview.Name = "Preview"
        Me.Preview.Size = New System.Drawing.Size(372, 204)
        Me.Preview.TabIndex = 0
        Me.Preview.Zoom = 1
        '
        'OrderPrintPreview
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Preview})
        Me.Name = "OrderPrintPreview"
        Me.Size = New System.Drawing.Size(380, 208)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public WithEvents Document As Order
    Public WithEvents PrintDoc As New PrintDocument()

    Public Sub New(ByVal document As Order)
        ' This is required to make sure the controls that were added at
        ' design-time are actually rendered.
        Me.New()

        ' Store a reference to the document and refresh the display.
        Me.Document = document
        RefreshList(Me, Nothing)
    End Sub

    Private Sub RefreshList(ByVal sender As Object, ByVal e As System.EventArgs) Handles Document.DocumentChanged
        ' Setting this property starts the preview,
        ' even if the PrintDoc document is already assigned.
        Preview.Document = PrintDoc
    End Sub

    ' Tracks placement while printing.
    Private ItemNumber As Integer

    ' The print font.
    Private PrintFont As New Font("Tahoma", 14, FontStyle.Bold)

    Private Sub PrintDoc_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDoc.PrintPage
        ' Tracks the line position on the page.
        Dim y As Integer = 70

        ' Step through the items and write them to the page.
        Dim Item As OrderItem
        Dim ItemProduct As Product
        Dim ItemDisplay As ListViewItem
        For ItemNumber = ItemNumber To Document.Count - 1

            Item = Document.Item(ItemNumber)
            e.Graphics.DrawString(Item.ID.ToString(), PrintFont, Brushes.Black, 70, y)
            ItemProduct = PriceList.GetItem(Item.ID)
            e.Graphics.DrawString(ItemProduct.Name, PrintFont, Brushes.Black, 120, y)
            e.Graphics.DrawString(ItemProduct.Price.ToString(), PrintFont, Brushes.Black, 350, y)

            ' Check if more pages are required.
            If (y + 30) > e.MarginBounds.Height And ItemNumber < Document.Count - 1 Then
                e.HasMorePages = True
                Exit Sub
            End If

            ' Move to the next line.
            y += 20

        Next

        ' Printing is finished.
        ItemNumber = 0
        e.HasMorePages = False
    End Sub

End Class
