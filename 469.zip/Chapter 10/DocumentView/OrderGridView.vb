Public Class OrderGridView
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents list As System.Windows.Forms.ListView
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdRemove As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.list = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdRemove = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'list
        '
        Me.list.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.list.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.list.FullRowSelect = True
        Me.list.Location = New System.Drawing.Point(4, 4)
        Me.list.MultiSelect = False
        Me.list.Name = "list"
        Me.list.Size = New System.Drawing.Size(264, 136)
        Me.list.TabIndex = 0
        Me.list.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 30
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Name"
        Me.ColumnHeader2.Width = 100
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Price"
        Me.ColumnHeader3.Width = 50
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Description"
        Me.ColumnHeader4.Width = 200
        '
        'cmdAdd
        '
        Me.cmdAdd.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdAdd.Location = New System.Drawing.Point(280, 4)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(112, 28)
        Me.cmdAdd.TabIndex = 1
        Me.cmdAdd.Text = "Add Random Item"
        '
        'cmdRemove
        '
        Me.cmdRemove.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdRemove.Location = New System.Drawing.Point(280, 36)
        Me.cmdRemove.Name = "cmdRemove"
        Me.cmdRemove.Size = New System.Drawing.Size(112, 28)
        Me.cmdRemove.TabIndex = 2
        Me.cmdRemove.Text = "Remove Item"
        '
        'OrderGridView
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdRemove, Me.cmdAdd, Me.list})
        Me.Name = "OrderGridView"
        Me.Size = New System.Drawing.Size(396, 144)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public WithEvents Document As Order

    Public Sub New(ByVal document As Order)
        ' This is required to make sure the controls that were added at
        ' design-time are actually rendered.
        Me.New()

        ' Store a reference to the document and refresh the display.
        Me.Document = document
        RefreshList(Me, Nothing)
    End Sub

    Private Sub RefreshList(ByVal sender As Object, ByVal e As System.EventArgs) Handles Document.DocumentChanged
        If Not list Is Nothing Then

            ' For best performance, disable refreshes while updating the list.
            list.SuspendLayout()

            list.Items.Clear()

            ' Step through the list of items in the document.
            Dim Item As OrderItem
            Dim ItemProduct As Product
            Dim ItemDisplay As ListViewItem
            For Each Item In Me.Document
                ItemDisplay = list.Items.Add(Item.ID)
                ItemProduct = PriceList.GetItem(Item.ID)
                ItemDisplay.SubItems.Add(ItemProduct.Name)
                ItemDisplay.SubItems.Add(ItemProduct.Price)
                ItemDisplay.SubItems.Add(ItemProduct.Description)
            Next

            list.ResumeLayout()
        End If

    End Sub

    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        ' Add a random item.
        Dim RandomItem As New Random()
        Document.Add(New OrderItem(RandomItem.Next(1, 4)))
    End Sub

    Private Sub cmdRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
        ' Remove the current item.
        ' The ListView Is configured for single-selection only.
        Document.Remove(list.SelectedIndices(0))
    End Sub


End Class
