Public Class Parent
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents cmdClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents imgButtons As System.Windows.Forms.ImageList
    Friend WithEvents cmdOpen As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdSave As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdNew As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents cmdPreview As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Parent))
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.cmdNew = New System.Windows.Forms.ToolBarButton()
        Me.cmdOpen = New System.Windows.Forms.ToolBarButton()
        Me.cmdClose = New System.Windows.Forms.ToolBarButton()
        Me.cmdSave = New System.Windows.Forms.ToolBarButton()
        Me.imgButtons = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.cmdPreview = New System.Windows.Forms.ToolBarButton()
        Me.SuspendLayout()
        '
        'ToolBar1
        '
        Me.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.cmdNew, Me.cmdOpen, Me.cmdClose, Me.cmdSave, Me.ToolBarButton1, Me.cmdPreview})
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.imgButtons
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(520, 41)
        Me.ToolBar1.TabIndex = 3
        '
        'cmdNew
        '
        Me.cmdNew.ImageIndex = 3
        Me.cmdNew.Text = "New"
        '
        'cmdOpen
        '
        Me.cmdOpen.ImageIndex = 0
        Me.cmdOpen.Text = "Open"
        '
        'cmdClose
        '
        Me.cmdClose.ImageIndex = 1
        Me.cmdClose.Text = "Close"
        '
        'cmdSave
        '
        Me.cmdSave.ImageIndex = 2
        Me.cmdSave.Text = "Save"
        '
        'imgButtons
        '
        Me.imgButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgButtons.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgButtons.ImageStream = CType(resources.GetObject("imgButtons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgButtons.TransparentColor = System.Drawing.Color.Transparent
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'cmdPreview
        '
        Me.cmdPreview.ImageIndex = 4
        Me.cmdPreview.Text = "Preview"
        '
        'Parent
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(520, 370)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ToolBar1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.Name = "Parent"
        Me.Text = "MDI Parent"
        Me.ResumeLayout(False)

    End Sub

#End Region
    
    Private LastDir As String = "C:\Temp"

    Private Sub ToolBar1_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick

        If e.Button Is cmdOpen Then
            Dim dlgOpen As New OpenFileDialog()
            dlgOpen.InitialDirectory = LastDir
            dlgOpen.Filter = "Order Files (*.ord)|*.ord"

            If dlgOpen.ShowDialog() = DialogResult.OK Then
                Dim Doc As New Order()

                Try
                    Doc.Open(dlgOpen.FileName)
                Catch err As Exception
                    ' All exceptions bubble up to this level.
                    MessageBox.Show(err.ToString())
                    Exit Sub
                End Try

                Dim frmChild As New Child(Doc, Child.ViewType.ItemGrid)
                frmChild.MdiParent = Me
                frmChild.Show()
            End If

        ElseIf e.Button Is cmdNew Then
            Dim doc As New Order()
            Dim frmChild As New Child(Doc, Child.ViewType.ItemGrid)
            frmChild.MdiParent = Me
            frmChild.Show()

        ElseIf e.Button Is cmdSave Then
            If Not Me.ActiveMdiChild Is Nothing Then
                Dim dlgSave As New SaveFileDialog()
                Dim Doc As Order = CType(Me.ActiveMdiChild, Child).Document
                dlgSave.FileName = Doc.LastFileName
                dlgSave.Filter = "Order Files (*.ord)|*.ord"

                If dlgSave.ShowDialog() = DialogResult.OK Then
                    Try
                        Doc.save(dlgSave.FileName)
                        Me.ActiveMdiChild.Text = dlgSave.FileName
                    Catch err As Exception
                        ' All exceptions bubble up to this level.
                        MessageBox.Show(err.ToString())
                        Exit Sub
                    End Try
                End If
            End If

        ElseIf e.Button Is cmdClose Then
            If Not Me.ActiveMdiChild Is Nothing Then
                Me.ActiveMdiChild.Close()
            End If

        ElseIf e.Button Is cmdPreview Then
            If Not Me.ActiveMdiChild Is Nothing Then
                Dim Doc As Order = CType(Me.ActiveMdiChild, Child).Document

                Dim frmChild As New Child(Doc, Child.ViewType.PrintPreview)
                frmChild.MdiParent = Me
                frmChild.Show()
            End If
        End If

    End Sub

End Class
