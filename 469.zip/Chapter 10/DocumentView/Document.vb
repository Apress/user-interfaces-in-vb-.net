Public Class Order
    Inherits CollectionBase

    Event DocumentChanged(ByVal sender As Object, ByVal e As EventArgs)

    Private _LastFilename As String = "[New Order]"

    Public Property LastFileName() As String
        Get
            Return _LastFilename
        End Get
        Set(ByVal Value As String)
            _LastFilename = Value
        End Set
    End Property

    Public Sub Add(ByVal item As OrderItem)
        Me.List.Add(item)
        OnDocumentChanged(New EventArgs())
    End Sub

    Public Sub Remove(ByVal Index As Integer)
        ' Check to see if there is an item at the supplied index.
        If Index > Count - 1 Or Index < 0 Then
            Throw New System.IndexOutOfRangeException()
        Else
            List.RemoveAt(Index)
        End If
        OnDocumentChanged(New EventArgs())
    End Sub

    Public ReadOnly Property Item(ByVal Index As Integer) As OrderItem
        Get
            ' The appropriate item is retrieved from the List object and 
            ' explicitly cast to the OrderItem type.
            Return CType(List.Item(Index), OrderItem)
        End Get
    End Property

    Public Sub Open(ByVal filename As String)
        Dim s As New FileStream(filename, FileMode.Open)
        Dim r As New StreamReader(s)

        Do
            Me.Add(New OrderItem(CType(r.ReadLine, Integer)))
        Loop Until r.Peek() = -1

        r.Close()
        s.Close()

        ' By placing this last we ensure that the file will not be updated
        ' if a load error occurs.
        Me.LastFileName = filename
    End Sub

    Public Sub Save(ByVal filename As String)
        Dim s As New FileStream(filename, FileMode.Create)
        Dim w As New StreamWriter(s)

        Dim Item As OrderItem
        For Each Item In Me.List
            w.WriteLine(Item.ID)
        Next

        w.Close()
        s.Close()

        ' Note: a real pricing program would probably store the price in the file
        ' (required for orders) but update it to correspond with the current
        ' price for the item when the file is opened.

        ' By placing this last we ensure that the file will not be updated
        ' if a save error occurs.
        Me.LastFileName = filename
    End Sub

    Protected Sub OnDocumentChanged(ByVal e As EventArgs)
        ' Note that this currently occurs as items are added or removed,
        ' but not when they are edited. To overcome this would require adding
        ' an additional OrderItem change event.
        RaiseEvent DocumentChanged(Me, e)
    End Sub

End Class

Public Class OrderItem
    Public ID As Integer

    Public Sub New(ByVal ID As Integer)
        Me.ID = ID
    End Sub
End Class

Public Class Product
    Public Name As String
    Public Description As String
    Public Price As Decimal

    Public Sub New(ByVal name As String, ByVal description As String, ByVal price As Decimal)
        Me.Name = name
        Me.Description = description
        Me.Price = price
    End Sub
End Class

Public Class PriceList

    Public Shared Function GetItem(ByVal ID As Integer) As Product
        Select Case ID
            Case 1
                Return New Product("Sample Product 1", "Sample Description 1", 14.99)
            Case 2
                Return New Product("Sample Product 2", "Sample Description 2", 14.99)
            Case 3
                Return New Product("Sample Product 3", "Sample Description 3", 14.99)
            Case Else
                Throw New IndexOutOfRangeException("Not a valid product ID.")
        End Select
    End Function

End Class
