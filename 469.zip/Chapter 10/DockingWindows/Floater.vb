
Public Class Floater
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents tmrDock As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.tmrDock = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(138, 176)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.PictureBox2.Location = New System.Drawing.Point(2, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(134, 172)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'tmrDock
        '
        Me.tmrDock.Interval = 10
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button1.Location = New System.Drawing.Point(16, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 20)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Sample"
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button2.Location = New System.Drawing.Point(16, 36)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(108, 20)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Dockable"
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button3.Location = New System.Drawing.Point(16, 56)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 20)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Controls"
        '
        'Floater
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(138, 176)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button3, Me.Button2, Me.Button1, Me.PictureBox2, Me.PictureBox1})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Floater"
        Me.Text = "Floater"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Dim DockTestAt As Point

    Private Sub Floater_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Move

        Dim MouseAt As Point = Me.Owner.PointToClient(Me.Location)
        If MouseAt.X < 7 And MouseAt.X > -7 Then
            If Me.MouseButtons And MouseButtons.Left = MouseButtons.Left Then
                DockTestAt = MouseAt

                ' Show dock focus rectangle.
                CType(Me.Owner, MDIMain).DrawDockRectangle = True

                ' Reset timer to poll for MouseUp event.
                tmrDock.Enabled = False
                tmrDock.Enabled = True

            End If
        End If
    End Sub


    Private Sub tmrDock_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrDock.Tick
        If DockTestAt.X = Me.Owner.PointToClient(Me.Location).X And DockTestAt.Y = Me.Owner.PointToClient(Me.Location).Y Then
            If Me.MouseButtons = MouseButtons.None Then
                ' Dock in place.
                tmrDock.Enabled = False
                CType(Me.Owner, MDIMain).AddToDock(Me)
            End If
        Else
            ' Mouse has moved. Disable this dock attempt.
            tmrDock.Enabled = False
            CType(Me.Owner, MDIMain).DrawDockRectangle = False
        End If
    End Sub

  
    Private Sub Floater_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        CType(Me.Owner, MDIMain).DrawDockRectangle = False
    End Sub
End Class
