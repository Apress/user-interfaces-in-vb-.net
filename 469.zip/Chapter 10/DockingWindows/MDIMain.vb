Imports System.Drawing.Drawing2D

Public Class MDIMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents pnlDock As System.Windows.Forms.Panel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.pnlDock = New System.Windows.Forms.Panel()
        Me.SuspendLayout()
        '
        'pnlDock
        '
        Me.pnlDock.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left)
        Me.pnlDock.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.pnlDock.Name = "pnlDock"
        Me.pnlDock.Size = New System.Drawing.Size(148, 302)
        Me.pnlDock.TabIndex = 1
        Me.pnlDock.Visible = False
        '
        'MDIMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(534, 304)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlDock})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.Name = "MDIMain"
        Me.Text = "Dockable Window"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim frmFloat As New Floater()

    Private Sub MDIMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        frmFloat.Owner = Me
        frmFloat.Show()

    End Sub


    Public Property DrawDockRectangle() As Boolean
        Get
            Return pnlDOck.Visible
        End Get
        Set(ByVal Value As Boolean)
            pnlDock.Visible = Value
        End Set
    End Property

    Public Sub AddToDock(ByVal frm As Form)
        ' Allow the form to be contained in a container control.
        frm.TopLevel = False
        pnlDock.Controls.Add(frm)

        ' Don't let the form be dragged off.
        frm.WindowState = FormWindowState.Maximized
    End Sub


    Private Sub pnlDock_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlDock.Paint
        Dim DockCueBrush As New HatchBrush(HatchStyle.LightDownwardDiagonal, Color.White, Color.Gray)
        Dim DockCuePen As New Pen(DockCueBrush, 10)
        e.Graphics.DrawRectangle(DockCuePen, New Rectangle(0, 0, pnlDock.Width, pnlDock.Height))
    End Sub
End Class
