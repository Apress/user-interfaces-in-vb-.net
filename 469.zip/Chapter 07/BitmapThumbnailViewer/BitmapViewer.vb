Imports System.IO

Public Class BitmapViewer
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents pnlPictures As System.Windows.Forms.Panel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.pnlPictures = New System.Windows.Forms.Panel()
        Me.SuspendLayout()
        '
        'pnlPictures
        '
        Me.pnlPictures.AutoScroll = True
        Me.pnlPictures.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlPictures.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlPictures.Location = New System.Drawing.Point(1, 1)
        Me.pnlPictures.Name = "pnlPictures"
        Me.pnlPictures.Size = New System.Drawing.Size(530, 218)
        Me.pnlPictures.TabIndex = 0
        '
        'BitmapViewer
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlPictures})
        Me.DockPadding.All = 1
        Me.Name = "BitmapViewer"
        Me.Size = New System.Drawing.Size(532, 220)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Event PictureSelected(ByVal sender As Object, ByVal e As PictureSelectedEventArgs)

    ' The directory that will be scanned for image.
    Private _Directory As String

    ' Each picture box will be a square of _Dimension X _Dimension pixels.
    Private _Dimension As Integer

    ' The space between the images and the top, left, and right sides.
    Private _Border As Integer = 5

    ' The space between each image.
    Private _Spacing As Integer

    ' The images that were found in the selected directory.
    Private Images As New ArrayList()

    Public Property Directory() As String
        Get
            Return _Directory
        End Get
        Set(ByVal Value As String)
            _Directory = Value
            GetImages()
            UpdateDisplay()
        End Set
    End Property

    Public Property Dimension() As Integer
        Get
            Return _Dimension
        End Get
        Set(ByVal Value As Integer)
            _Dimension = Value
            GetImages()
            UpdateDisplay()
        End Set
    End Property

    Public Property Spacing() As Integer
        Get
            Return _Spacing
        End Get
        Set(ByVal Value As Integer)
            _Spacing = Value
            UpdateDisplay()
        End Set
    End Property


    Private Sub GetImages()
        Images.Clear()
        If Directory = "" Then Exit Sub

        Dim ThumbNail As Image
        Dim Dir As New DirectoryInfo(Directory), File As FileInfo
        For Each File In Dir.GetFiles("*.bmp")
            ThumbNail = Bitmap.FromFile(File.FullName).GetThumbnailImage(Dimension, Dimension, Nothing, Nothing)
            Images.Add(New NamedImage(ThumbNail, File.Name))
        Next

    End Sub

    Private Sub UpdateDisplay()

        ' Clear the current display.
        pnlPictures.Controls.Clear()

        ' Row and Col will track the current position where pictures are
        ' being inserted. They begin at the top-right corner.
        Dim Row As Integer = _Border, Col As Integer = _Border

        ' Iterate through the Images collection, and create PictureBox controls.
        Dim Image As NamedImage
        For Each Image In Images

            Dim pic As New PictureBox()
            pic.Image = Image.Image
            pic.Tag = Image.FileName
            pic.Size = New Size(_Dimension, _Dimension)
            pic.Location = New Point(Col, Row)
            pic.BorderStyle = BorderStyle.FixedSingle

            ' StrechImage mode gives us the "thumbnail" ability.
            ' pic.SizeMode = PictureBoxSizeMode.StretchImage

            ' Register to receive the click event.
            AddHandler pic.Click, AddressOf pic_Click

            ' Display the picture.
            pnlPictures.Controls.Add(pic)

            ' Move to the next column.
            Col += _Dimension + _Spacing

            ' Move to next line if no more pictures will fit.
            If (Col + _Dimension + _Spacing + _Border) > Me.Width Then
                Col = _Border
                Row += _Dimension + _Spacing
            End If

        Next

    End Sub

    Public Sub RefreshImages()
        GetImages()
        UpdateDisplay()
    End Sub

    Protected Overrides Sub OnSizeChanged(ByVal e As System.EventArgs)
        UpdateDisplay()
        MyBase.OnSizeChanged(e)
    End Sub

    Private picSelected As PictureBox

    Private Sub pic_Click(ByVal sender As Object, ByVal e As System.EventArgs)

        ' Clear the border style from the last selected picture box.
        If Not picSelected Is Nothing Then
            picSelected.BorderStyle = BorderStyle.FixedSingle
        End If

        ' Get the new selection.
        picSelected = CType(sender, PictureBox)
        picSelected.BorderStyle = BorderStyle.Fixed3D

        ' Fire the selection event.
        Dim Args As New PictureSelectedEventArgs(picSelected.Tag, picSelected.Image)
        RaiseEvent PictureSelected(Me, Args)

    End Sub

    Private Class NamedImage
        Public Image As Image
        Public FileName As String

        Public Sub New(ByVal image, ByVal fileName)
            Me.Image = image
            Me.FileName = fileName
        End Sub
    End Class

End Class



Public Class PictureSelectedEventArgs
    Inherits EventArgs

    Public FileName As String
    Public Image As Image

    Public Sub New(ByVal fileName As String, ByVal image As Image)
        Me.FileName = fileName
        Me.Image = Image
    End Sub
End Class