<ProvideProperty("HelpID", GetType(String))> _
Public Class HelpIconProvider
    Inherits Component
    Implements IExtenderProvider

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

#End Region

    Private ContextID As New Hashtable()
    Private Pictures As New Hashtable()
    Private _HelpFile As String

    Public Function CanExtend(ByVal extendee As Object) As Boolean Implements System.ComponentModel.IExtenderProvider.CanExtend
        If extendee Is GetType(Control) Then
            If CType(extendee, Control).FindForm Is Nothing Then
                Return False
            Else
                Return True
            End If
        Else
            Return False
        End If
    End Function

    Public Property HelpFile() As String
        Get
            Return _HelpFile
        End Get
        Set(ByVal Value As String)
            _HelpFile = Value
        End Set
    End Property

    Public Sub SetHelpID(ByVal extendee As Object, ByVal value As String)
        Dim ctrl As Control = CType(extendee, Control)

        ' Specifying an empty value removes the extension.
        If value = "" Then
            ContextID.Remove(extendee)

            ' Remove the picture.
            Dim pic As PictureBox = CType(pictures(extendee), PictureBox)
            RemoveHandler pic.DoubleClick, AddressOf PicDoubleClick

            pic.Parent.Controls.Remove(pic)
            Pictures.Remove(extendee)


        Else
            ContextID(extendee) = value

            ' Create new icon.
            Dim pic As New PictureBox()
            'pic.Image = Image.FromFile("Help.gif")
            Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(HelpIconResources))
            pic.Image = CType(Resources.GetObject("PictureBox1.Image"), System.Drawing.Bitmap)

            ' Store a reference to the related control in the PictureBox.
            pic.Tag = extendee

            pic.Size = New Size(16, 16)
            pic.Location = New Point(ctrl.Right + 10, ctrl.Top)
            ctrl.Parent.Controls.Add(pic)

            ' Register for DoubleClick event.
            AddHandler pic.DoubleClick, AddressOf PicDoubleClick

            ' Store a reference to the PictureBox so it can be easily removed
            ' if needed.
            Pictures(extendee) = pic
        End If
    End Sub

    Public Function GetHelpID(ByVal extendee As Object) As String
        If Not ContextID(extendee) Is Nothing Then
            Return ContextID(extendee).ToString()
        Else
            Return String.Empty
        End If
    End Function


    Public Sub PicDoubleClick(ByVal sender As Object, ByVal e As EventArgs)
        ' Debugging message.
        MessageBox.Show("Help triggered")

        ' Invoke help for control.
        Dim ctrlRelated As Control = CType(CType(sender, Control).Tag, Control)
        Help.ShowHelp(ctrlRelated, _HelpFile, HelpNavigator.Topic, ContextID(ctrlRelated).ToString())
    End Sub

End Class