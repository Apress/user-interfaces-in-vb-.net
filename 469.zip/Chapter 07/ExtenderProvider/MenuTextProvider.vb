<ProvideProperty("HelpText", GetType(String))> _
Public Class MenuTextProvider
    Inherits StatusBar
    Implements IExtenderProvider

    Private HelpText As New Hashtable()

    Public Function CanExtend(ByVal extendee As Object) As Boolean Implements System.ComponentModel.IExtenderProvider.CanExtend
        If extendee Is GetType(MenuItem) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub SetHelpText(ByVal extendee As Object, ByVal value As String)
        ' Specifying an empty value removes the extension.
        If value = "" Then
            HelpText.Remove(extendee)
            RemoveHandler CType(extendee, MenuItem).Select, AddressOf MenuSelect
        Else
            HelpText(extendee) = value
            AddHandler CType(extendee, MenuItem).Select, AddressOf MenuSelect
        End If
    End Sub

    Public Function GetHelpText(ByVal extendee As Object) As String
        If Not HelpText(extendee) Is Nothing Then
            Return HelpText(extendee).ToString()
        Else
            Return String.Empty
        End If
    End Function

    Private Sub MenuSelect(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Text = HelpText(sender).ToString()
    End Sub

End Class
