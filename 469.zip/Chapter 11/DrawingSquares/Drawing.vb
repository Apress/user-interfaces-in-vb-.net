Public Class Drawing
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mnuForm As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuNewSquare As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLabel As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuColorChange As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuForm = New System.Windows.Forms.ContextMenu()
        Me.mnuNewSquare = New System.Windows.Forms.MenuItem()
        Me.mnuLabel = New System.Windows.Forms.ContextMenu()
        Me.mnuColorChange = New System.Windows.Forms.MenuItem()
        '
        'mnuForm
        '
        Me.mnuForm.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuNewSquare})
        '
        'mnuNewSquare
        '
        Me.mnuNewSquare.Index = 0
        Me.mnuNewSquare.Text = "Create New Square"
        '
        'mnuLabel
        '
        Me.mnuLabel.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuColorChange})
        '
        'mnuColorChange
        '
        Me.mnuColorChange.Index = 0
        Me.mnuColorChange.Text = "Change Color"
        '
        'Drawing
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(624, 410)
        Me.ContextMenu = Me.mnuForm
        Me.Name = "Drawing"
        Me.Text = "Drawing"

    End Sub

#End Region


    ' Keep track of when fake drag or resize mode is enabled.
    Private IsDragging As Boolean = False
    Private IsResizing As Boolean = False

    ' Store the location where the user clicked on the control.
    Private ClickOffsetX, ClickOffsetY As Integer

    Private Sub lbl_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)

        ' Retrieve a reference to the active label.
        Dim CurrentCtrl As Control
        CurrentCtrl = CType(sender, Control)

        If e.Button = MouseButtons.Right Then
            ' Show the context menu.
            CurrentCtrl.ContextMenu.Show(CurrentCtrl, New Point(e.X, e.Y))

        ElseIf e.Button = MouseButtons.Left Then
            If (e.X + 5) > CurrentCtrl.Width And (e.Y + 5) > CurrentCtrl.Height Then
                ' The mouse pointer is in the bottom right corner,
                ' so resizing mode is appropriate.
                IsResizing = True
            Else
                ' The mouse is somewhere else, so dragging mode is
                ' appropriate.
                IsDragging = True
                ClickOffsetX = e.X
                ClickOffsetY = e.Y
            End If
        End If

    End Sub

    Private Sub lbl_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        IsDragging = False
        IsResizing = False
    End Sub

    Private Sub lbl_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)

        ' Retrieve a reference to the active label.
        Dim CurrentCtrl As Control
        CurrentCtrl = CType(sender, Control)

        If IsDragging = True Then
            ' Move the control.
            CurrentCtrl.Left = e.X + CurrentCtrl.Left - ClickOffsetX
            CurrentCtrl.Top = e.Y + CurrentCtrl.Top - ClickOffsetY

        ElseIf IsResizing = True Then
            ' Resize the control.
            CurrentCtrl.Width = e.X
            CurrentCtrl.Height = e.Y

        Else
            ' Change the pointer if the mouse is in the bottom corner.
            If (e.X + 5) > CurrentCtrl.Width And (e.Y + 5) > CurrentCtrl.Height Then
                CurrentCtrl.Cursor = Cursors.SizeNWSE
            Else
                CurrentCtrl.Cursor = Cursors.Arrow
            End If
        End If
    End Sub


    Private Sub Drawing_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        If e.Button = MouseButtons.Right Then
            Me.ContextMenu.Show(Me, New Point(e.X, e.Y))
        End If
    End Sub

    Private Sub mnuNewSquare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNewSquare.Click

        ' Create and configure the "square".
        Dim NewLabel As New Label()
        NewLabel.Size = New Size(40, 40)
        NewLabel.BorderStyle = BorderStyle.FixedSingle

        ' To determine where to place the label, you need to convert the 
        ' current screen-based mouse coordinates into relative form coordinates.
        NewLabel.Location = Me.PointToClient(Me.MousePosition)

        ' Attach a context menu to the label.
        NewLabel.ContextMenu = mnuLabel

        ' Connect the label to all its event handlers.
        AddHandler NewLabel.MouseDown, AddressOf lbl_MouseDown
        AddHandler NewLabel.MouseMove, AddressOf lbl_MouseMove
        AddHandler NewLabel.MouseUp, AddressOf lbl_MouseUp

        ' Add the label to the form.
        Me.Controls.Add(NewLabel)

    End Sub

    Private Sub mnuColorChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuColorChange.Click
        ' Show color dialog.
        Dim dlgColor As New ColorDialog()
        dlgColor.ShowDialog()

        ' Change label background.
        mnuLabel.SourceControl.BackColor = dlgColor.Color
    End Sub
End Class
