Public Class SingeLineFlow

    Private WithEvents _Container As Control
    Private components As System.ComponentModel.IContainer
    Private _margin As Integer

    Public Sub New(ByVal parent As Control, ByVal margin As Integer)
        _Container = parent
        _margin = margin
        UpdateLayout(Me, Nothing)
    End Sub

    Public Property Margin() As Integer
        Get
            Return _margin
        End Get
        Set(ByVal Value As Integer)
            _margin = Value
        End Set
    End Property

    ' This is public so it can be triggered manually if needed.
    Public Sub UpdateLayout(ByVal sender As Object, ByVal e As System.Windows.Forms.LayoutEventArgs) Handles _Container.Layout
        Dim ctrl As Control
        Dim y As Integer
        For Each ctrl In _Container.Controls
            y += Margin
            ctrl.Left = Margin
            ctrl.Top = y
            ctrl.Width = _Container.Width
            ctrl.Height = Margin
        Next
    End Sub

    Private Sub InitializeComponent()

    End Sub
End Class
