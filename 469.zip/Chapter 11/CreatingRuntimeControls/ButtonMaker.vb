Public Class ButtonMaker
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmdCreate As System.Windows.Forms.Button
    Friend WithEvents txtTop As System.Windows.Forms.TextBox
    Friend WithEvents txtLeft As System.Windows.Forms.TextBox
    Friend WithEvents Status As System.Windows.Forms.StatusBar
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdCreate = New System.Windows.Forms.Button()
        Me.txtTop = New System.Windows.Forms.TextBox()
        Me.txtLeft = New System.Windows.Forms.TextBox()
        Me.Status = New System.Windows.Forms.StatusBar()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Left:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Top:"
        '
        'cmdCreate
        '
        Me.cmdCreate.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdCreate.Location = New System.Drawing.Point(36, 84)
        Me.cmdCreate.Name = "cmdCreate"
        Me.cmdCreate.Size = New System.Drawing.Size(112, 28)
        Me.cmdCreate.TabIndex = 2
        Me.cmdCreate.Text = "Create Button"
        '
        'txtTop
        '
        Me.txtTop.Location = New System.Drawing.Point(76, 24)
        Me.txtTop.Name = "txtTop"
        Me.txtTop.Size = New System.Drawing.Size(68, 21)
        Me.txtTop.TabIndex = 3
        Me.txtTop.Text = "50"
        '
        'txtLeft
        '
        Me.txtLeft.Location = New System.Drawing.Point(76, 52)
        Me.txtLeft.Name = "txtLeft"
        Me.txtLeft.Size = New System.Drawing.Size(68, 21)
        Me.txtLeft.TabIndex = 4
        Me.txtLeft.Text = "200"
        '
        'Status
        '
        Me.Status.Location = New System.Drawing.Point(0, 184)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(408, 22)
        Me.Status.TabIndex = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.txtLeft, Me.Label2, Me.cmdCreate, Me.txtTop})
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(168, 128)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.GroupBox2.Location = New System.Drawing.Point(0, 176)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(412, 4)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        '
        'ButtonMaker
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(408, 206)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox2, Me.GroupBox1, Me.Status})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ButtonMaker"
        Me.Text = "Button Maker"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private ButtonCount As Integer = 0

    Private Sub cmdCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreate.Click
        ButtonCount += 1

        Dim NewButton As New Button()
        NewButton.FlatStyle = FlatStyle.System
        NewButton.Text = "Button " & ButtonCount.ToString()
        NewButton.Left = Val(txtLeft.Text)
        NewButton.Top = Val(txtTop.Text)

        AddHandler NewButton.Click, AddressOf ButtonHandler

        Me.Controls.Add(NewButton)
    End Sub

    Private Sub ButtonHandler(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Status.Text = " You clicked ... "
        Status.Text &= CType(sender, Button).Text
    End Sub
End Class
