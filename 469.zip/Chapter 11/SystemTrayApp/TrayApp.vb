Imports System.IO

Public Module App

    ' Define the system tray icon control.
    Private AppIcon As New NotifyIcon()

    ' Define the menu.
    Private SysTrayMenu As New ContextMenu()
    Private WithEvents DisplayFiles As New MenuItem("Display New Files")
    Private WithEvents ExitApp As New MenuItem("Exit")

    ' Define the file system watcher, at a list to store filenames.
    Private WithEvents Watch As New FileSystemWatcher()
    Private NewFiles As New ArrayList()


    Public Sub Main()
        ' Configure the system tray icon.
        Dim ico As New Icon("icon.ico")
        AppIcon.Icon = ico
        AppIcon.Text = "My .NET Application"

        ' Place the menu items in the menu.
        SysTrayMenu.MenuItems.Add(DisplayFiles)
        SysTrayMenu.MenuItems.Add(ExitApp)
        AppIcon.ContextMenu = SysTrayMenu

        ' Show the system tray icon.
        AppIcon.Visible = True

        ' Hook up the file watcher.
        Watch.Path = "c:\"
        Watch.IncludeSubdirectories = True
        Watch.EnableRaisingEvents = True

        ' Because no forms are being displayed, you need this 
        ' statement to stop the application from automatically ending.
        Application.Run()
    End Sub

    Private Sub ExitApp_Click(ByVal sender As Object, _
     ByVal e As System.EventArgs) Handles ExitApp.Click
        Application.Exit()
    End Sub

    Private Sub DisplayFiles_Click(ByVal sender As Object, _
     ByVal e As System.EventArgs) Handles DisplayFiles.Click
        Dim frmFileList As New FileList()
        frmFileList.FillList(NewFiles)
        frmFileList.Show()
    End Sub

    Private Sub Watch_Created(ByVal sender As Object, ByVal e As System.IO.FileSystemEventArgs) Handles Watch.Created
        NewFiles.Add(e.Name)
    End Sub

End Module