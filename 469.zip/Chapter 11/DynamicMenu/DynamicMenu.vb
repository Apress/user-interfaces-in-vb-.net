Imports System.Data.SqlClient

Public Class DynamicMenu
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOpen As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSave As System.Windows.Forms.MenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTools As System.Windows.Forms.MenuItem
    Friend WithEvents mnuManageHardware As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSetupUserAccounts As System.Windows.Forms.MenuItem
    Friend WithEvents mnuChangeDisplay As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Friend WithEvents mnuContents As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAbout As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuClose As System.Windows.Forms.MenuItem
    Friend WithEvents cmdUser As System.Windows.Forms.Button
    Friend WithEvents cmdAdmin As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuMain = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuNew = New System.Windows.Forms.MenuItem()
        Me.mnuOpen = New System.Windows.Forms.MenuItem()
        Me.mnuClose = New System.Windows.Forms.MenuItem()
        Me.mnuSave = New System.Windows.Forms.MenuItem()
        Me.MenuItem12 = New System.Windows.Forms.MenuItem()
        Me.mnuExit = New System.Windows.Forms.MenuItem()
        Me.mnuTools = New System.Windows.Forms.MenuItem()
        Me.mnuManageHardware = New System.Windows.Forms.MenuItem()
        Me.mnuSetupUserAccounts = New System.Windows.Forms.MenuItem()
        Me.mnuChangeDisplay = New System.Windows.Forms.MenuItem()
        Me.mnuHelp = New System.Windows.Forms.MenuItem()
        Me.mnuContents = New System.Windows.Forms.MenuItem()
        Me.MenuItem13 = New System.Windows.Forms.MenuItem()
        Me.mnuAbout = New System.Windows.Forms.MenuItem()
        Me.cmdUser = New System.Windows.Forms.Button()
        Me.cmdAdmin = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuTools, Me.mnuHelp})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuNew, Me.mnuOpen, Me.mnuClose, Me.mnuSave, Me.MenuItem12, Me.mnuExit})
        Me.mnuFile.Text = "File"
        '
        'mnuNew
        '
        Me.mnuNew.Index = 0
        Me.mnuNew.Text = "New"
        '
        'mnuOpen
        '
        Me.mnuOpen.Index = 1
        Me.mnuOpen.Text = "Open"
        '
        'mnuClose
        '
        Me.mnuClose.Index = 2
        Me.mnuClose.Text = "Close"
        '
        'mnuSave
        '
        Me.mnuSave.Index = 3
        Me.mnuSave.Text = "Save"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 4
        Me.MenuItem12.Text = "-"
        '
        'mnuExit
        '
        Me.mnuExit.Index = 5
        Me.mnuExit.Text = "Exit"
        '
        'mnuTools
        '
        Me.mnuTools.Index = 1
        Me.mnuTools.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuManageHardware, Me.mnuSetupUserAccounts, Me.mnuChangeDisplay})
        Me.mnuTools.Text = "Tools"
        '
        'mnuManageHardware
        '
        Me.mnuManageHardware.Index = 0
        Me.mnuManageHardware.Text = "Manage Hardware"
        '
        'mnuSetupUserAccounts
        '
        Me.mnuSetupUserAccounts.Index = 1
        Me.mnuSetupUserAccounts.Text = "Setup User Accounts"
        '
        'mnuChangeDisplay
        '
        Me.mnuChangeDisplay.Index = 2
        Me.mnuChangeDisplay.Text = "Change Display"
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 2
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuContents, Me.MenuItem13, Me.mnuAbout})
        Me.mnuHelp.Text = "Help"
        '
        'mnuContents
        '
        Me.mnuContents.Index = 0
        Me.mnuContents.Text = "Contents"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 1
        Me.MenuItem13.Text = "-"
        '
        'mnuAbout
        '
        Me.mnuAbout.Index = 2
        Me.mnuAbout.Text = "About"
        '
        'cmdUser
        '
        Me.cmdUser.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdUser.Location = New System.Drawing.Point(12, 68)
        Me.cmdUser.Name = "cmdUser"
        Me.cmdUser.Size = New System.Drawing.Size(80, 24)
        Me.cmdUser.TabIndex = 0
        Me.cmdUser.Text = "User Level"
        '
        'cmdAdmin
        '
        Me.cmdAdmin.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdAdmin.Location = New System.Drawing.Point(100, 68)
        Me.cmdAdmin.Name = "cmdAdmin"
        Me.cmdAdmin.Size = New System.Drawing.Size(80, 24)
        Me.cmdAdmin.TabIndex = 1
        Me.cmdAdmin.Text = "Admin Level"
        '
        'DynamicMenu
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(200, 105)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdAdmin, Me.cmdUser})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Menu = Me.mnuMain
        Me.Name = "DynamicMenu"
        Me.Text = "Dynamic Menu"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DynamicMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        cmdUser_Click(Nothing, Nothing)

    End Sub

    Private Sub SearchMenu(ByVal Menu As Menu, ByVal dtPermissions As DataTable)

        Dim RowMatch() As DataRow

        Dim mnuItem As MenuItem
        For Each mnuItem In Menu.MenuItems

            ' See if this menu item has a corresponding row.
            RowMatch = dtPermissions.Select("ControlName = '" & mnuItem.Text & "'")

            ' If it does, configure the menu item state accordingly.
            If RowMatch.GetLength(0) > 0 Then
                Select Case RowMatch(0)("State")
                    Case DBPermissions.State.Hidden
                        mnuItem.Visible = False
                    Case DBPermissions.State.Disabled
                        mnuItem.Enabled = False
                End Select
            Else
                mnuItem.Visible = True
                mnuItem.Enabled = True
            End If

            ' Search recursively through any submenus.
            If mnuItem.MenuItems.Count > 0 Then
                SearchMenu(mnuItem, dtPermissions)
            End If

        Next

    End Sub

    Private Sub cmdUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUser.Click
        Dim dtPermissions As DataTable = DBPermissions.GetPermissions(DBPermissions.Level.User)
        SearchMenu(Me.Menu, dtPermissions)
    End Sub

    Private Sub cmdAdmin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdmin.Click
        Dim dtPermissions As DataTable = DBPermissions.GetPermissions(DBPermissions.Level.Admin)
        SearchMenu(Me.Menu, dtPermissions)
    End Sub
End Class

Public Class DBPermissions

    Enum State
        Normal = 0
        Disabled = 1
        Hidden = 2
    End Enum

    Enum Level
        Admin
        User
    End Enum

    Private Shared con As New SqlConnection("Data Source=localhost;" & _
     "Integrated Security=SSPI;Initial Catalog=Apress;")

    Public Shared Function GetPermissions(ByVal UserLevel As Level) As DataTable

        con.Open()

        Dim SelectPermissions As String = "SELECT * FROM Permissions "

        Select Case UserLevel
            Case Level.Admin
                SelectPermissions &= "WHERE LevelName = 'Admin'"
            Case Level.User
                SelectPermissions &= "WHERE LevelName = 'User'"
        End Select

        Dim cmd As New SqlCommand(SelectPermissions, con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim ds As New DataSet()
        adapter.Fill(ds, "Permissions")

        con.Close()

        Return ds.Tables("Permissions")

    End Function

End Class