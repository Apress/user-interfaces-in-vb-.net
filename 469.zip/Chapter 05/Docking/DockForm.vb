Imports System.ComponentModel
Public Class DockForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents txtDock As System.Windows.Forms.TextBox
    Friend WithEvents pnlDock As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents udDockPaddingForm As System.Windows.Forms.NumericUpDown
    Friend WithEvents udDockPaddingPanel As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lstDockPanel As System.Windows.Forms.ComboBox
    Friend WithEvents lstDockTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdUpdate As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtDock = New System.Windows.Forms.TextBox()
        Me.pnlDock = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.udDockPaddingForm = New System.Windows.Forms.NumericUpDown()
        Me.udDockPaddingPanel = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lstDockPanel = New System.Windows.Forms.ComboBox()
        Me.lstDockTextBox = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdUpdate = New System.Windows.Forms.Button()
        Me.pnlDock.SuspendLayout()
        CType(Me.udDockPaddingForm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udDockPaddingPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtDock
        '
        Me.txtDock.Dock = System.Windows.Forms.DockStyle.Left
        Me.txtDock.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDock.Location = New System.Drawing.Point(20, 20)
        Me.txtDock.Multiline = True
        Me.txtDock.Name = "txtDock"
        Me.txtDock.Size = New System.Drawing.Size(108, 266)
        Me.txtDock.TabIndex = 0
        Me.txtDock.Text = "I'm docked to the edge of this Panel." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "The Panel is docked to the edge of the f" & _
        "orm." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "The Panel's DockPadding gives the necessary room to breathe."
        '
        'pnlDock
        '
        Me.pnlDock.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtDock})
        Me.pnlDock.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlDock.DockPadding.All = 20
        Me.pnlDock.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnlDock.Name = "pnlDock"
        Me.pnlDock.Size = New System.Drawing.Size(224, 306)
        Me.pnlDock.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Set Form's DockPadding:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Set Panel's DockPadding:"
        '
        'udDockPaddingForm
        '
        Me.udDockPaddingForm.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.udDockPaddingForm.Location = New System.Drawing.Point(160, 32)
        Me.udDockPaddingForm.Name = "udDockPaddingForm"
        Me.udDockPaddingForm.Size = New System.Drawing.Size(52, 21)
        Me.udDockPaddingForm.TabIndex = 4
        '
        'udDockPaddingPanel
        '
        Me.udDockPaddingPanel.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.udDockPaddingPanel.Location = New System.Drawing.Point(160, 56)
        Me.udDockPaddingPanel.Name = "udDockPaddingPanel"
        Me.udDockPaddingPanel.Size = New System.Drawing.Size(52, 21)
        Me.udDockPaddingPanel.TabIndex = 5
        Me.udDockPaddingPanel.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Dock Panel To:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 128)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Dock TextBox To:"
        '
        'lstDockPanel
        '
        Me.lstDockPanel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.lstDockPanel.Location = New System.Drawing.Point(156, 100)
        Me.lstDockPanel.Name = "lstDockPanel"
        Me.lstDockPanel.Size = New System.Drawing.Size(92, 21)
        Me.lstDockPanel.TabIndex = 8
        '
        'lstDockTextBox
        '
        Me.lstDockTextBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.lstDockTextBox.Location = New System.Drawing.Point(156, 124)
        Me.lstDockTextBox.Name = "lstDockTextBox"
        Me.lstDockTextBox.Size = New System.Drawing.Size(92, 21)
        Me.lstDockTextBox.TabIndex = 9
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdUpdate, Me.udDockPaddingForm, Me.udDockPaddingPanel, Me.lstDockPanel, Me.Label3, Me.Label4, Me.lstDockTextBox, Me.Label2, Me.Label1})
        Me.GroupBox1.Location = New System.Drawing.Point(172, 20)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(284, 224)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Configure"
        '
        'cmdUpdate
        '
        Me.cmdUpdate.Location = New System.Drawing.Point(160, 180)
        Me.cmdUpdate.Name = "cmdUpdate"
        Me.cmdUpdate.Size = New System.Drawing.Size(84, 24)
        Me.cmdUpdate.TabIndex = 10
        Me.cmdUpdate.Text = "Update"
        '
        'DockForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(468, 306)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.pnlDock})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "DockForm"
        Me.Text = "Docking At Work"
        Me.pnlDock.ResumeLayout(False)
        CType(Me.udDockPaddingForm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udDockPaddingPanel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
        Me.DockPadding.All = udDockPaddingForm.Value
        pnlDock.DockPadding.All = udDockPaddingPanel.Value

        ' Now we use some rather unusual code to translate the string
        '  in the listbox into an enumeration object that can be used
        '  to set the Dock property.
        ' This looks quite strange, but is actually just one more
        '  part of the shared class library.

        ' First we get the converter that can do the job.
        Dim Converter As TypeConverter
        Converter = TypeDescriptor.GetConverter(Dock.GetType)

        ' Then we use it to convert the string.
        pnlDock.Dock = Converter.ConvertFromString(lstDockPanel.Text)
        txtDock.Dock = Converter.ConvertFromString(lstDockTextBox.Text)
    End Sub

    Private Sub DockForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lstDockPanel.Items.AddRange(System.Enum.GetNames(Dock.GetType))
        lstDockTextBox.Items.AddRange(System.Enum.GetNames(Dock.GetType))
    End Sub
End Class
