Public Class Owner
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents cmdAddOwnership As System.Windows.Forms.Button
    Friend WithEvents cmdReleaseOwnership As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdAddOwnership = New System.Windows.Forms.Button()
        Me.cmdReleaseOwnership = New System.Windows.Forms.Button()
        Me.label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdAddOwnership
        '
        Me.cmdAddOwnership.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdAddOwnership.Location = New System.Drawing.Point(12, 180)
        Me.cmdAddOwnership.Name = "cmdAddOwnership"
        Me.cmdAddOwnership.Size = New System.Drawing.Size(120, 32)
        Me.cmdAddOwnership.TabIndex = 0
        Me.cmdAddOwnership.Text = "Set Ownership"
        '
        'cmdReleaseOwnership
        '
        Me.cmdReleaseOwnership.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdReleaseOwnership.Location = New System.Drawing.Point(148, 180)
        Me.cmdReleaseOwnership.Name = "cmdReleaseOwnership"
        Me.cmdReleaseOwnership.Size = New System.Drawing.Size(128, 32)
        Me.cmdReleaseOwnership.TabIndex = 1
        Me.cmdReleaseOwnership.Text = "Remove Ownership"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(40, 32)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(216, 80)
        Me.label1.TabIndex = 5
        Me.label1.Text = "To test form ownership, try minimizing this form when the second form is owned. T" & _
        "hen try, minimizing it when the second form is not owned."
        '
        'Owner
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(288, 222)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.label1, Me.cmdReleaseOwnership, Me.cmdAddOwnership})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Owner"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Basic Form"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private frmOwned As New OwnedForm()

    Private Sub Owner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Show()
        frmOwned.Show()
    End Sub

    Private Sub cmdAddOwnership_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddOwnership.Click
        Me.AddOwnedForm(frmOwned)
        frmOwned.lblState.Text = "I'm Owned"
    End Sub

    Private Sub cmdReleaseOwnership_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReleaseOwnership.Click
        Me.RemoveOwnedForm(frmOwned)
        frmOwned.lblState.Text = "I'm Free!"
    End Sub
End Class
