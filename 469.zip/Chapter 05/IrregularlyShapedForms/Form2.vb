Imports System.Drawing.Drawing2D
Public Class Form2
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents picTwo As System.Windows.Forms.PictureBox
    Friend WithEvents imgSelectedButtons As System.Windows.Forms.ImageList
    Friend WithEvents picThree As System.Windows.Forms.PictureBox
    Friend WithEvents picFour As System.Windows.Forms.PictureBox
    Friend WithEvents picOne As System.Windows.Forms.PictureBox
    Friend WithEvents imgNormalButtons As System.Windows.Forms.ImageList
    Friend WithEvents lblDrag As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form2))
        Me.picTwo = New System.Windows.Forms.PictureBox()
        Me.picOne = New System.Windows.Forms.PictureBox()
        Me.picThree = New System.Windows.Forms.PictureBox()
        Me.picFour = New System.Windows.Forms.PictureBox()
        Me.imgSelectedButtons = New System.Windows.Forms.ImageList(Me.components)
        Me.imgNormalButtons = New System.Windows.Forms.ImageList(Me.components)
        Me.lblDrag = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'picTwo
        '
        Me.picTwo.Image = CType(resources.GetObject("picTwo.Image"), System.Drawing.Bitmap)
        Me.picTwo.Location = New System.Drawing.Point(40, 112)
        Me.picTwo.Name = "picTwo"
        Me.picTwo.Size = New System.Drawing.Size(209, 28)
        Me.picTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTwo.TabIndex = 0
        Me.picTwo.TabStop = False
        Me.picTwo.Tag = "1"
        '
        'picOne
        '
        Me.picOne.Image = CType(resources.GetObject("picOne.Image"), System.Drawing.Bitmap)
        Me.picOne.Location = New System.Drawing.Point(40, 80)
        Me.picOne.Name = "picOne"
        Me.picOne.Size = New System.Drawing.Size(209, 26)
        Me.picOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picOne.TabIndex = 1
        Me.picOne.TabStop = False
        Me.picOne.Tag = "0"
        '
        'picThree
        '
        Me.picThree.Image = CType(resources.GetObject("picThree.Image"), System.Drawing.Bitmap)
        Me.picThree.Location = New System.Drawing.Point(40, 144)
        Me.picThree.Name = "picThree"
        Me.picThree.Size = New System.Drawing.Size(209, 27)
        Me.picThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picThree.TabIndex = 2
        Me.picThree.TabStop = False
        Me.picThree.Tag = "2"
        '
        'picFour
        '
        Me.picFour.Image = CType(resources.GetObject("picFour.Image"), System.Drawing.Bitmap)
        Me.picFour.Location = New System.Drawing.Point(40, 176)
        Me.picFour.Name = "picFour"
        Me.picFour.Size = New System.Drawing.Size(209, 29)
        Me.picFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picFour.TabIndex = 3
        Me.picFour.TabStop = False
        Me.picFour.Tag = "3"
        '
        'imgSelectedButtons
        '
        Me.imgSelectedButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth16Bit
        Me.imgSelectedButtons.ImageSize = New System.Drawing.Size(209, 29)
        Me.imgSelectedButtons.ImageStream = CType(resources.GetObject("imgSelectedButtons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgSelectedButtons.TransparentColor = System.Drawing.Color.Transparent
        '
        'imgNormalButtons
        '
        Me.imgNormalButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth16Bit
        Me.imgNormalButtons.ImageSize = New System.Drawing.Size(209, 29)
        Me.imgNormalButtons.ImageStream = CType(resources.GetObject("imgNormalButtons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgNormalButtons.TransparentColor = System.Drawing.Color.Transparent
        '
        'lblDrag
        '
        Me.lblDrag.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.lblDrag.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDrag.Location = New System.Drawing.Point(76, 36)
        Me.lblDrag.Name = "lblDrag"
        Me.lblDrag.Size = New System.Drawing.Size(124, 20)
        Me.lblDrag.TabIndex = 4
        Me.lblDrag.Text = "      < Drag Here! >"
        '
        'Form2
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(67, Byte), CType(101, Byte), CType(192, Byte))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Bitmap)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblDrag, Me.picFour, Me.picThree, Me.picOne, Me.picTwo})
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim Path As New GraphicsPath()
        Path.AddEllipse(10, 50, Me.Width - 20, Me.Height - 60)
        Me.Region = New Region(Path)

        picOne.Image = imgNormalButtons.Images(0)
        picTwo.Image = imgNormalButtons.Images(1)
        picThree.Image = imgNormalButtons.Images(2)
        picFour.Image = imgNormalButtons.Images(3)

    End Sub


    Private Sub pic_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picOne.MouseEnter, picTwo.MouseEnter, picThree.MouseEnter, picFour.MouseEnter
        Dim pic As PictureBox = CType(sender, PictureBox)
        pic.Image = imgSelectedButtons.Images(CType(pic.Tag, Integer))
    End Sub

    Private Sub pic_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picOne.MouseLeave, picTwo.MouseLeave, picThree.MouseLeave, picFour.MouseLeave
        Dim pic As PictureBox = CType(sender, PictureBox)
        pic.Image = imgNormalButtons.Images(CType(pic.Tag, Integer))
    End Sub


    Private Sub pic_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picOne.MouseDown, picTwo.MouseDown, picThree.MouseDown, picFour.MouseDown
        Dim pic As PictureBox = CType(sender, PictureBox)
        pic.Top += 2
        pic.Left += 2
    End Sub

    Private Sub pic_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picOne.MouseUp, picTwo.MouseUp, picThree.MouseUp, picFour.MouseUp
        Dim pic As PictureBox = CType(sender, PictureBox)
        pic.Top -= 2
        pic.Left -= 2
    End Sub

    Dim FormDragging As Boolean
    Dim PointClicked As Point

    Private Sub lblDrag_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblDrag.MouseDown

        'Set drag mode on.
        FormDragging = True

        ' Store the offset where the control was clicked.
        PointClicked = New Point(e.X, e.Y)

    End Sub

    Private Sub lblDrag_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblDrag.MouseMove

        If FormDragging Then
            Dim PointMoveTo As Point

            ' Find the current mouse position in screen coordinates.
            PointMoveTo = Me.PointToScreen(New Point(e.X, e.Y))

            ' Compensate for the position the control was clicked.
            PointMoveTo.Offset(-PointClicked.X, -PointClicked.Y)

            ' Compensate for the non-client region (title bar).
            ' This code is not necessary if you explicitly hide the title bar
            '  by setting the form's BorderStyle to None.
            PointMoveTo.Offset(0, -25)

            ' Move the form.
            Me.Location = PointMoveTo
        End If

    End Sub

    Private Sub lblDrag_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblDrag.MouseUp
        FormDragging = False
    End Sub


    Private Sub picFour_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picFour.Click
        Me.Close()
    End Sub
End Class
