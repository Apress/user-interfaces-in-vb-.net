Imports System.IO

Public Class HTMLSplit
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents AxWebBrowser1 As AxSHDocVw.AxWebBrowser
    Friend WithEvents cmdHide As System.Windows.Forms.Button
    Friend WithEvents cmdShow As System.Windows.Forms.Button
    Friend WithEvents pnlFileList As System.Windows.Forms.Panel
    Friend WithEvents pnlShow As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Splitter2 As System.Windows.Forms.Splitter
    Friend WithEvents AxWebBrowser2 As AxSHDocVw.AxWebBrowser
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(HTMLSplit))
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.pnlFileList = New System.Windows.Forms.Panel()
        Me.cmdHide = New System.Windows.Forms.Button()
        Me.cmdShow = New System.Windows.Forms.Button()
        Me.pnlShow = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.AxWebBrowser2 = New AxSHDocVw.AxWebBrowser()
        Me.Splitter2 = New System.Windows.Forms.Splitter()
        Me.pnlFileList.SuspendLayout()
        Me.pnlShow.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.AxWebBrowser2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListView1
        '
        Me.ListView1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(172, 260)
        Me.ListView1.TabIndex = 0
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "File"
        Me.ColumnHeader1.Width = 99
        '
        'pnlFileList
        '
        Me.pnlFileList.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdHide, Me.ListView1})
        Me.pnlFileList.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlFileList.Location = New System.Drawing.Point(5, 5)
        Me.pnlFileList.Name = "pnlFileList"
        Me.pnlFileList.Size = New System.Drawing.Size(176, 284)
        Me.pnlFileList.TabIndex = 1
        '
        'cmdHide
        '
        Me.cmdHide.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdHide.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdHide.Location = New System.Drawing.Point(0, 264)
        Me.cmdHide.Name = "cmdHide"
        Me.cmdHide.Size = New System.Drawing.Size(172, 20)
        Me.cmdHide.TabIndex = 1
        Me.cmdHide.Text = "<< Hide"
        '
        'cmdShow
        '
        Me.cmdShow.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left)
        Me.cmdShow.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmdShow.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShow.Name = "cmdShow"
        Me.cmdShow.Size = New System.Drawing.Size(16, 284)
        Me.cmdShow.TabIndex = 17
        Me.cmdShow.Text = ">"
        '
        'pnlShow
        '
        Me.pnlShow.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdShow})
        Me.pnlShow.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlShow.Location = New System.Drawing.Point(181, 5)
        Me.pnlShow.Name = "pnlShow"
        Me.pnlShow.Size = New System.Drawing.Size(20, 284)
        Me.pnlShow.TabIndex = 18
        Me.pnlShow.Visible = False
        '
        'Panel3
        '
        Me.Panel3.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1})
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(204, 131)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(247, 158)
        Me.Panel3.TabIndex = 22
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(248, 157)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'Splitter1
        '
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Splitter1.Location = New System.Drawing.Point(204, 128)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(247, 3)
        Me.Splitter1.TabIndex = 21
        Me.Splitter1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.AddRange(New System.Windows.Forms.Control() {Me.AxWebBrowser2})
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(204, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(247, 123)
        Me.Panel2.TabIndex = 20
        '
        'AxWebBrowser2
        '
        Me.AxWebBrowser2.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.AxWebBrowser2.ContainingControl = Me
        Me.AxWebBrowser2.Enabled = True
        Me.AxWebBrowser2.Location = New System.Drawing.Point(-4, 0)
        Me.AxWebBrowser2.OcxState = CType(resources.GetObject("AxWebBrowser2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWebBrowser2.Size = New System.Drawing.Size(248, 120)
        Me.AxWebBrowser2.TabIndex = 0
        '
        'Splitter2
        '
        Me.Splitter2.Location = New System.Drawing.Point(201, 5)
        Me.Splitter2.Name = "Splitter2"
        Me.Splitter2.Size = New System.Drawing.Size(3, 284)
        Me.Splitter2.TabIndex = 19
        Me.Splitter2.TabStop = False
        '
        'HTMLSplit
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.ClientSize = New System.Drawing.Size(456, 294)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel3, Me.Splitter1, Me.Panel2, Me.Splitter2, Me.pnlShow, Me.pnlFileList})
        Me.DockPadding.All = 5
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "HTMLSplit"
        Me.Text = "HTML Split"
        Me.pnlFileList.ResumeLayout(False)
        Me.pnlShow.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.AxWebBrowser2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        Try
            AxWebBrowser2.Navigate2("C:\Program Files\Microsoft Visual Studio .NET\FrameworkSDK\Samples\" & ListView1.SelectedItems(0).Text)
            Dim r As StreamReader = File.OpenText("C:\Program Files\Microsoft Visual Studio .NET\FrameworkSDK\Samples\" & ListView1.SelectedItems(0).Text)
        TextBox1.Text = r.ReadToEnd()
        Catch
        End Try
    End Sub

    Private Sub HTMLSplit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim f As FileInfo
        Dim d As New DirectoryInfo(Application.StartupPath & "\..\view\")
        For Each f In d.GetFiles()
            ListView1.Items.Add(f.Name)
        Next

    End Sub


    Private Sub cmdHide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHide.Click
        pnlFileList.Visible = False
        pnlShow.Visible = True
    End Sub

    Private Sub cmdShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdShow.Click
        pnlShow.Visible = False
        pnlFileList.Visible = True

    End Sub
End Class
