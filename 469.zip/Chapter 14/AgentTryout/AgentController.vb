Public Class AgentController

    ' Agent variable.
    Private AgentChar As AgentObjects.IAgentCtlCharacterEx

    ' Name of the initialized character.
    Private CharacterName As String

    ' Balloon constants
    Const BalloonOn As Short = 1
    Const SizeToText As Short = 2
    Const AutoHide As Short = 4
    Const AutoPace As Short = 8


    Public Sub New(ByVal AgentHost As AxAgentObjects.AxAgent, _
                   ByVal Character As String)

        AgentHost.Characters.Load(Character)
        AgentChar = AgentHost.Characters(Character)

        CharacterName = Character

        ' You could put your own options in this menu, if desired.
        AgentChar.AutoPopupMenu = False


        ' Set balloon style.
        AgentChar.Balloon.Style = AgentChar.Balloon.Style Or BalloonOn
        AgentChar.Balloon.Style = AgentChar.Balloon.Style Or SizeToText
        AgentChar.Balloon.Style = AgentChar.Balloon.Style Or AutoHide
        AgentChar.Balloon.Style = AgentChar.Balloon.Style And (Not AutoPace)

    End Sub

    Public Sub Dispose()
        If AgentChar.Visible = True Then
            AgentChar.StopAll()
            AgentChar.Hide()
        End If
    End Sub

    Public Sub Show()
        AgentChar.Show()
    End Sub

    Public Sub Hide()
        AgentChar.Hide()
    End Sub

    Public Sub StopAll()
        AgentChar.StopAll()
    End Sub

    Public Sub Speak(ByRef Text As String)
        AgentChar.StopAll()
        AgentChar.Speak(Text, "")
    End Sub

    Public Sub Think(ByRef Text As String)
        AgentChar.StopAll()
        AgentChar.Think(Text)
    End Sub

    Public Sub Animate(ByVal Animation As String)
        AgentChar.StopAll()
        AgentChar.Play(Animation)
    End Sub

    Public Sub MoveTo(ByVal x As Single, ByVal y As Single)
        AgentChar.MoveTo(x, y)
    End Sub

    Public Sub GestureAt(ByVal x As Single, ByVal y As Single)
        AgentChar.GestureAt(x, y)
    End Sub

    Public Function GetAnimations() As Array
        Dim List As New ArrayList()
        Dim AnimationName As String
        For Each AnimationName In AgentChar.AnimationNames
            List.Add(AnimationName)
        Next
        Return List.ToArray(GetType(String))
    End Function

    ' Tests if the agent is visible.
    ' If the agent is not visible it will be shown.
    Private Function IsAgentVisible() As Boolean
        If AgentChar.Visible Then
            IsAgentVisible = True
        Else
            IsAgentVisible = False
            AgentChar.Show()
        End If
    End Function

End Class

